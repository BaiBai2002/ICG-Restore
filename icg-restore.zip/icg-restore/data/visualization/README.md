# Visualization outputs (PNG)

Publication-style figures are **generated from source** so the repository stays honest about binary provenance.

**Expected files after** `PYTHONPATH=src python examples/demo_visualize_topology.py`:

- `EC-S_topology.png`, `EC-M_topology.png`, `EC-L_topology.png` — synthetic heterogeneous scene graphs.  
- `pipeline_overview.png` — public artifact pipeline diagram.

**Additional** files may appear after `examples/demo_end_to_end_artifact.py` (e.g. `demo_end_to_end_topology.png`, `demo_end_to_end_task_graph.png`).

If these PNGs are **absent** in a fresh clone, that is **expected** until you run the scripts above; CI may generate them in-memory without committing. Maintainers may **commit** PNGs for Zenodo or supplementary ZIPs once visuals are frozen for a given tag.

See `docs/visualization_guide.md`.
