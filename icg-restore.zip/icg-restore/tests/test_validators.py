from __future__ import annotations

from icg_restore_artifact.repair.validation_rules import (
    validate_package_against_intent,
    validate_primitive_catalog,
)
from icg_restore_artifact.task.generation import generate_task
from icg_restore_artifact.task.task_templates import BACKBONE_PATH_RECOVERY
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.validators.suite import run_validator_suite


def test_cross_validation_catches_step_budget() -> None:
    intent = {
        "scenario_id": "x",
        "budget": {"max_primitive_steps": 1, "energy_units": 10},
        "rule_bounds": {"max_primitive_steps": 1},
    }
    package = {
        "scenario_id": "x",
        "graph_id": "g",
        "primitives": [{"name": "activate_node", "args": {}}, {"name": "activate_node", "args": {}}],
    }
    errs = validate_package_against_intent(intent, package)
    assert errs


def test_cross_validation_catches_forbidden() -> None:
    intent = {"scenario_id": "x", "rule_bounds": {"forbidden_primitives": ["activate_node"]}}
    package = {"scenario_id": "x", "graph_id": "g", "primitives": [{"name": "activate_node", "args": {}}]}
    errs = validate_package_against_intent(intent, package)
    assert any("forbidden" in e for e in errs)


def test_catalog_rejects_unknown_primitive() -> None:
    package = {"primitives": [{"name": "unknown_primitive", "args": {}}]}
    errs = validate_primitive_catalog(package)
    assert errs


def test_validator_suite_clean_on_demo_shapes() -> None:
    topo = build_topology("EC-S", seed=0)
    intent = generate_task(BACKBONE_PATH_RECOVERY, "EC-S", seed=1)
    package = {
        "schema_version": intent["schema_version"],
        "package_id": "p-test",
        "scenario_id": intent["scenario_id"],
        "graph_id": topo["graph_id"],
        "primitives": [
            {"name": "activate_node", "args": {"node_id": topo["nodes"][0]["id"], "power_level": 0.9}},
            {"name": "clear_fault_flag", "args": {"node_id": topo["nodes"][0]["id"]}},
        ],
    }
    report = run_validator_suite(topology=topo, intent=intent, package=package)
    assert report == {}
