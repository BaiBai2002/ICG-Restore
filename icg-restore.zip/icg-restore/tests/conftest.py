"""Pytest setup: headless Matplotlib backend for CI and local runs."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
