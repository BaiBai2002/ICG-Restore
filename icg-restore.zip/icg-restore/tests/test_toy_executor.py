from __future__ import annotations

from icg_restore_artifact.evaluation.toy_executor import run_toy_executor
from icg_restore_artifact.task.build_task import build_task_package
from icg_restore_artifact.task.generation import generate_task
from icg_restore_artifact.task.task_templates import BACKBONE_PATH_RECOVERY
from icg_restore_artifact.topology.build_topology import build_topology


def test_run_toy_executor_reports_illustrative_indicators() -> None:
    topo = build_topology("EC-S", seed=3)
    intent = generate_task(BACKBONE_PATH_RECOVERY, "EC-S", seed=0)
    package = build_task_package(
        package_id="p1",
        scenario_id=intent["scenario_id"],
        graph_id=topo["graph_id"],
        primitives=[
            {"name": "activate_node", "args": {"node_id": "bg-0", "power_level": 0.9}},
            {"name": "activate_node", "args": {"node_id": "cs-0", "power_level": 0.85}},
            {"name": "restore_link", "args": {"edge_id": "e-2", "target_utilization": 0.8}},
        ],
        task_type=BACKBONE_PATH_RECOVERY,
    )
    final, report, steps = run_toy_executor(topo, package)
    assert len(steps) == 3
    assert report.path_restoration_gain >= -1.0
    assert report.illustrative_only is True
    assert isinstance(report.coordination_delay_change, float)
