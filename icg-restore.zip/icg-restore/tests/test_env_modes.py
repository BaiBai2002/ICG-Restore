from __future__ import annotations

from icg_restore_artifact.environment.modes import STABLE_RECOVERY, list_environment_modes
from icg_restore_artifact.environment.simulation import (
    build_initial_simulation_state,
    generate_environment_trace,
    simulate_env_step,
)
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.utils.schema_utils import validate_document


def test_public_environment_modes() -> None:
    modes = list_environment_modes()
    assert STABLE_RECOVERY in modes
    assert len(modes) == 5


def test_simulate_env_step_is_deterministic() -> None:
    topo = build_topology("EC-S", seed=0)
    s0 = build_initial_simulation_state(topo, seed=9)
    s1 = simulate_env_step(s0, STABLE_RECOVERY, step_idx=0, seed=9)
    s2 = simulate_env_step(s0, STABLE_RECOVERY, step_idx=0, seed=9)
    assert s1 == s2
    assert s1["step_clock"] == 0


def test_generate_environment_trace_validates() -> None:
    topo = build_topology("EC-S", seed=1)
    trace = generate_environment_trace(
        length=4,
        seed=11,
        trace_id="t-test",
        topology=topo,
        graph_id=topo["graph_id"],
    )
    validate_document("environment_trace.schema.json", trace)
    assert len(trace["steps"]) == 4
