from __future__ import annotations

from pathlib import Path

from icg_restore_artifact.config import data_dir
from icg_restore_artifact.repair.validation_rules import validate_primitive_catalog
from icg_restore_artifact.utils.io_utils import read_json
from icg_restore_artifact.utils.schema_utils import validate_document


def test_invalid_package_passes_schema_fails_catalog() -> None:
    path = data_dir() / "task_examples" / "package_invalid_unknown_primitive.json"
    assert Path(path).is_file()
    doc = read_json(path)
    validate_document("task_package.schema.json", doc)
    errs = validate_primitive_catalog(doc)
    assert errs
    assert any("unknown primitive" in e.lower() or "not in toy catalog" in e.lower() for e in errs)
