from __future__ import annotations

from icg_restore_artifact.task.build_task import build_task_package
from icg_restore_artifact.task.generation import generate_task
from icg_restore_artifact.task.task_templates import BACKBONE_PATH_RECOVERY
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.utils.schema_utils import validate_document


def test_generate_task_and_package_validate() -> None:
    topo = build_topology("EC-S", seed=0)
    intent = generate_task(BACKBONE_PATH_RECOVERY, "EC-S", seed=1)
    validate_document("task_intent.schema.json", intent)
    package = build_task_package(
        package_id="p1",
        scenario_id=intent["scenario_id"],
        graph_id=topo["graph_id"],
        primitives=[{"name": "clear_fault_flag", "args": {"node_id": topo["nodes"][0]["id"]}}],
        task_type=BACKBONE_PATH_RECOVERY,
    )
    validate_document("task_package.schema.json", package)
