from __future__ import annotations

from pathlib import Path

from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.visualization.plot_pipeline_overview import plot_pipeline_overview
from icg_restore_artifact.visualization.plot_task_graph import plot_task_graph
from icg_restore_artifact.visualization.plot_topology import plot_topology


def test_plot_topology_writes_png(tmp_path: Path) -> None:
    topo = build_topology("EC-S", seed=1)
    out = plot_topology(topo, tmp_path / "t.png")
    assert out.is_file()
    assert out.stat().st_size > 500


def test_plot_task_graph_writes_png(tmp_path: Path) -> None:
    pkg = {
        "package_id": "p",
        "primitives": [
            {"name": "activate_node", "args": {}},
            {"name": "restore_link", "args": {}},
        ],
    }
    out = plot_task_graph(pkg, tmp_path / "tg.png")
    assert out.is_file()
    assert out.stat().st_size > 400


def test_plot_pipeline_overview_writes_png(tmp_path: Path) -> None:
    out = plot_pipeline_overview(tmp_path / "pipe.png")
    assert out.is_file()
    assert out.stat().st_size > 800
