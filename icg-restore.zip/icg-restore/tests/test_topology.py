from __future__ import annotations

from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.utils.schema_utils import validate_document


def test_build_topology_all_scales_validate() -> None:
    for scale in ("EC-S", "EC-M", "EC-L"):
        doc = build_topology(scale, seed=3)
        validate_document("topology.schema.json", doc)
        assert doc["scale"] == scale
        assert doc["graph_id"]
        assert doc["metadata"]["node_count"] == len(doc["nodes"])
