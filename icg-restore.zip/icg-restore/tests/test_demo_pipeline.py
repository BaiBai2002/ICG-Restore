from __future__ import annotations

from icg_restore_artifact.demo.demo_pipeline import run_toy_demo


def test_run_toy_demo_produces_metrics_and_toy_indicators() -> None:
    out = run_toy_demo(seed=0)
    assert out["validation_cross"] == []
    assert out["validation_catalog"] == []
    assert out["validator_suite"] == {}
    assert "primitive_count" in out["metrics"]
    assert out["metrics"]["primitive_count"] == 3
    assert "environment_trace" in out
    assert out["toy_indicators"]["illustrative_only"] is True
    assert "path_restoration_gain" in out["toy_indicators"]
    assert "environment_state_after_mode_step" in out
