# Release checklist — ICG-Restore public artifact

Use this list before tagging a version (e.g. `v0.1.0`) or depositing on Zenodo. **Every item should pass or be explicitly waived in writing.**

## A. Content safety (nothing prohibited)

- [ ] No full **paper result tables** (wide CSV/TeX aggregates from internal runs).
- [ ] No **confidential LLM prompts** or production system prompts.
- [ ] No **hidden benchmark instances** or proprietary instance IDs beyond synthetic/fixture scope.
- [ ] No **full evaluation corpus**, raw **traces**, or **complete experiment logs**.
- [ ] No **trained model weights** or checkpoints.
- [ ] No **internal-only** modules copied verbatim from a private repo without clearance.
- [ ] No API **keys**, **tokens**, or `.env` with secrets (verify `.gitignore`).

## B. Honesty and scope

- [ ] `README.md` and `docs/*.md` state that the **toy executor** is **not** the paper evaluation engine.
- [ ] No sentence claims **bit-identical** reproduction of **paper tables** from this repo alone.
- [ ] `data/topo_examples/` **notes** still distinguish **illustrative slices** from full generator output where applicable.
- [ ] `CITATION.cff` **preferred-citation** updated with **final authors, venue, volume, pages, DOI** when the article is published (or supplemented by a separate bibliographic file).

## C. Technical consistency

- [ ] `pip install -e ".[dev]"` succeeds; `PYTHONPATH=src python -m pytest` passes.
- [ ] `python examples/demo_validate_examples.py` passes (including **expected failure** path for the invalid package fixture).
- [ ] **Optional but recommended:** run `examples/demo_visualize_topology.py` and attach or commit PNGs for the supplementary bundle you submit.
- [ ] `pyproject.toml` dependencies match `requirements.txt` for runtime pins.
- [ ] No broken imports (grep / test import smoke).

## D. Schema and data

- [ ] All `data/*_examples/*.json` validate against `schemas/` (except where tests document intentional semantic invalidity after schema validation).

## E. GitHub / archival

- [ ] `LICENSE` and `CITATION.cff` present.
- [ ] Tag matches `version` in `pyproject.toml` / `CITATION.cff` if you keep them aligned.
- [ ] Zenodo (or equivalent) DOI recorded in README/citation once minted.

**Current audit (maintainer-recorded):** Items are **unmarked** until you execute the release on your machine; this file is the process template.

## Appendix — point-in-time workspace review (polish pass)

The following were verified on the maintainer’s working copy of **this** tree only (not the parent monorepo):

- No `outputs/`, `runs/`, or `*.log` evaluation trees present inside `icg-restore-artifact/`.
- No wide result tables (e.g. `main_results.csv`) under `icg-restore-artifact/`.
- Content search for obvious secret patterns (`sk-`, `OPENAI_API_KEY`, etc.) under `icg-restore-artifact/` returned **no** hits in source or data files (only legitimate prose in `README` mentioning that keys are **not** used).

**Re-run** these checks before every public push; this appendix does not replace your institutional review.
