# GitHub upload guide — ICG-Restore public artifact

This document explains how to publish **`icg-restore-artifact`** as a **standalone** public repository **without** leaking materials from a larger internal codebase.

## What to upload

Upload **only** the contents of this `icg-restore-artifact` directory (the package root that contains `README.md`, `pyproject.toml`, `schemas/`, `src/`, `examples/`, `tests/`, `docs/`, `data/`, `LICENSE`, `CITATION.cff`, and release docs).

**Include:**

- Source under `src/icg_restore_artifact/`
- JSON Schemas, small `data/*_examples/` fixtures, and **optional** committed PNGs under `data/visualization/` if you freeze them for a release
- Documentation, examples, tests, `RELEASE_CHECKLIST.md`, this guide

## What not to upload

**Never** copy into this repo from internal trees:

- `outputs/`, `runs/`, `llm_raw_responses/`, full **metrics JSONL**, or **paper table** exports  
- Confidential **prompts**, **API** dashboards, or **model** weights  
- Full **benchmark** pickles, **seed registries** linked to confidential instances  
- **Internal-only** evaluation drivers that regenerate canonical paper tables  

If you use `git` from a monorepo, **initialize a new repository** rooted at `icg-restore-artifact/` (or use `git subtree split`) so history does not embed parent paths.

## Initialize the GitHub repository

1. Create an **empty** repository on GitHub (no README auto-init if you already have one locally).
2. Locally:

```bash
cd icg-restore-artifact
git init
git add .
git status   # verify no secrets or outputs
git commit -m "Initial public artifact: ICG-Restore supplementary software"
git branch -M main
git remote add origin git@github.com:YOUR_ORG/icg-restore-artifact.git
git push -u origin main
```

Replace `YOUR_ORG/icg-restore-artifact` with your account and repository name.

## Tag the first release

After `RELEASE_CHECKLIST.md` is satisfied:

```bash
git tag -a v0.1.0 -m "ICG-Restore public artifact v0.1.0"
git push origin v0.1.0
```

On GitHub, create a **Release** from that tag; attach a **ZIP** matching the tag if your venue requires a fixed archive.

## Citing the paper in the repository

1. **Update `preferred-citation` in `CITATION.cff`** with the camera-ready **author list**, **venue**, **volume**, **issue**, **pages**, and **DOI** once available. GitHub surfaces `CITATION.cff` in the repository sidebar.
2. **Mirror** the same bibliographic entry in `README.md` § Citation (ACM/IEEE/APA line) if reviewers expect human-readable text.
3. If you use **Zenodo**, add the software DOI to `README.md` and optionally to `CITATION.cff` under `identifiers` (Zenodo provides the exact YAML snippet).

**Software citation wording (example pattern):**  
“ICG-Restore public artifact v0.1.0 [version], [URL or DOI], MIT License.”

**Article citation:** Always cite the **peer-reviewed article** as the primary research reference; cite **this repo** as **supplementary software**, not as the source of paper table values.

## Post-upload

- Enable **Dependabot** or equivalent if policy requires it.  
- Add a **security policy** (`SECURITY.md`) if your institution mandates contact for vulnerabilities.  
- Link the artifact from the **journal supplementary portal** using the **tag URL** or **Zenodo DOI**.
