# Environment modes

## Role

Environment modes represent **non-stationary abstract conditions** (failures, congestion, observation delays, isolation drift) that, in the full study, couple to **proxy execution** and validation. Here they are **enumerated labels** plus **step-indexed events** that update a **reduced state vector** (`simulation.py`).

## Artifact vocabulary

Defined in `environment/modes.py` as human-readable strings:

- Stable Recovery  
- Secondary Failure  
- Congestion Escalation  
- Delayed Observation  
- Regional Isolation Drift  

State-update rules are **minimal and deterministic** (seeded per step). They **do not** reproduce proprietary scenario scripts from the internal repository.

## Events and traces

- Single events validate against `environment_event.schema.json` (`step_idx`, `mode`, `payload`).
- Traces validate against `environment_trace.schema.json` and are produced by `generate_environment_trace`.

`simulation.py` (not a separate legacy `state_update` module) implements stepping and trace assembly.

## Limitations

Updates are **pedagogical**. No claim is made that they match operational network dynamics or operator procedures.
