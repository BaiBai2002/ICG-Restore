# JSON Schema identifiers

Schema files under `schemas/` set the **`$id`** field to URIs of the form `https://example.org/icg-restore-artifact/...`. These strings serve as **stable, versioned identifiers** for the schema resources in the sense of JSON Schema Draft 2020-12. They are **not** deployed as live HTTPS endpoints by default; tools resolve schemas from the repository filesystem. If your archival workflow requires resolvable URIs (e.g., permanent redirects to a GitHub tag), replace the namespace consistently and record the mapping in release notes.
