# Reproducibility

## Randomness

Generators consume an explicit integer **`seed`** through `utils/random_utils.new_rng` (**stdlib `random.Random` only**; **NumPy is not required**), limiting cross-platform floating-point divergence in toy sampling.

## Software environment

- **Python** ≥ 3.10  
- Dependencies: `pyproject.toml` / `requirements.txt` (includes **pydantic**, **PyYAML**, **jsonschema**, **matplotlib**, **networkx**)  
- Optional dev: **pytest**, **ruff**, **pytest-cov**

For journal computational reproducibility statements, record **interpreter version**, **`pip freeze` or lockfile**, and **commit hash** for the artifact version you cite.

## What “reproducible” means here

| Asserted | Not asserted |
|----------|----------------|
| Byte-stable **JSON** from `build_topology`, `generate_task`, and `export_topology_json` under fixed `(seed, code version)` on a given platform | Identity with **unreleased** internal benchmark JSON |
| **`pytest`** passing without network or API keys | Reproduction of **LLM** outputs or **paper tables** |
| Deterministic **environment** traces for fixed `(length, seed, schedule)` | Operational field replay |

## Scripts and tests

`examples/demo_*.py` print seeds and paths where relevant. `python -m pytest` exercises schemas, generators, simulation, visualization smoke tests, validators, and the demo pipeline **without** external services.

## Honesty requirement

If a future release adds LLM backends, they must remain **optional**, **keyless in CI**, and **documented** as non-deterministic unless a frozen mock is used.
