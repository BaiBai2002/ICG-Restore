# Topology design (artifact level)

## Design goals

Artifact topologies are **typed, labeled graphs** representing the **heterogeneous scene graph** layer at a **synthetic, abstract** resolution: entities correspond to coordination, backbone, core service, relay, access, and channel abstractions. Design goals:

1. **Schema validity** — Every generated document validates against `topology.schema.json`.
2. **Closed vocabularies** — Node and edge `type` fields are drawn from `topology/node_types.py` and `topology/edge_types.py`.
3. **Determinism** — `build_topology(scale, seed)` is deterministic for fixed `(scale, seed)` (see `reproducibility.md`).

## Node model

Each node includes:

- **`id`** — Stable identifier within the document.
- **`type`** — One of the six public node classes (coordination center, backbone gateway, core service node, relay node, access cluster, channel resource).
- **`label`** — Short human-readable label for figures.
- **`attributes`** — JSON object for region, synthetic operational status, load factor, and other **non-operational** annotations used by toy simulators.

## Edge model

Each edge includes **`source`**, **`target`**, **`type`** (physical connectivity, logical dependency, service bearing, channel mapping), and **`attributes`** (e.g., latency class, residual capacity, degradation flag). Attributes are **synthetic**; they do not originate from live network management systems.

## Scale labels

**EC-S**, **EC-M**, and **EC-L** control generator **counts** via `config.SCALE_PROFILES`. **Frozen JSON** under `data/topo_examples/` may use a **compact motif** with an explicit note in `notes` when the file is an illustrative slice rather than the full graph emitted by `build_topology` for that label.

## Export

`topology_export.export_topology_json` writes UTF-8 JSON with **sorted keys** for diff-stable archives.
