# Artifact scope

## Included in this public release

1. **Synthetic heterogeneous scene graph construction** (`build_topology`) at EC-S, EC-M, and EC-L **labels**, with deterministic seeds and documented `SCALE_PROFILES` in source.
2. **Task intent–like documents** (`generate_task`, schemas) that encode goals, priorities, budgets, time windows, constraints, and completion criteria—**without** confidential **task intent compilation** prompts.
3. **Task packages**—ordered **abstract restoration primitives**—for examining **staged planning** at the data layer.
4. **Environment simulation** as discrete **events** and **traces** over a reduced state vector (not operational digital twins).
5. **JSON Schemas** for topology, task intent, task package, environment events, and environment traces.
6. **Validators** (`validators/`, `repair/validation_rules.py`): schema completeness, rule alignment, toy causal and budget/window checks—**a public specification layer**, not proprietary repair code.
7. **Visualization** (NetworkX + Matplotlib): topology, task chain, pipeline overview figures suitable for supplementary PDFs.
8. **Toy abstract executor** with explicit **illustrative** indicators—**no** equivalence to the paper’s **safe executor / abstract evaluator** stack.
9. **`pytest`** scripts and **`examples/`** that run **offline** (no API keys).

## Explicitly excluded

| Material | Reason |
|----------|--------|
| Full benchmark corpora identical to confidential paper instances | Prevents leakage of labor-intensive or policy-sensitive instance sets |
| Complete result tables, internal aggregation, significance pipelines | Keeps **published tables** as the sole authoritative numerical surface |
| Confidential or paper-identical LLM prompts and backbone routing | IP and ethics; artifact stays **model-agnostic** at code level |
| Raw traces, token ledgers tied to production, full logs | Size, privacy, integrity |
| Trained weights | Method is planning-centric; weights are out of scope |
| Canonical drivers that regenerate **exact** paper tables | Internal engineering |

## Reader obligation

Cite this software **as supplementary material**. **Do not** cite toy metrics or demo bundles as if they were **paper-reported evaluation outcomes**.
