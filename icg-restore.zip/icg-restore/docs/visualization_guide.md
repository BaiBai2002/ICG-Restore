# Visualization guide

## Dependencies

Figures use **NetworkX** for layout and **Matplotlib** for rendering. Continuous integration and local tests set the **Agg** backend via `tests/conftest.py` so no display server is required.

## Topology

`plot_topology` draws the **heterogeneous scene graph**: node color encodes **node type**; line style and color encode **edge type**; the background is **white** for print-friendly supplementary material.

## Task graph

`plot_task_graph` renders the **primitive chain** of a **task package** as a directed path. Arrows indicate **staged** step order at the **plan** level, not geographic routing.

## Pipeline overview

`plot_pipeline_overview` summarizes the **public artifact** flow (construction → task generation → validation → environment simulation → toy executor → export). It explicitly labels the executor as **illustrative**.

## Outputs

- **Regenerate** canonical PNGs: `examples/demo_visualize_topology.py` → `data/visualization/` (EC-S/M/L topology, pipeline overview).
- **End-to-end** demos may add `demo_end_to_end_*.png` in the same directory.
- Vector formats (PDF/SVG) may be exported by maintainers for camera-ready supplementary ZIPs; this repository standardizes on **PNG** for portability.
