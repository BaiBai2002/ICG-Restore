# Release notes

## 0.1.0

**Public supplementary artifact (initial release).**

- JSON Schemas: topology (synthetic heterogeneous scene graph), task intent, task package, environment event, environment trace.
- Deterministic `build_topology` for EC-S / EC-M / EC-L scale labels; `generate_task` for four public task-type identifiers.
- Environment modes and `simulate_env_step` / `generate_environment_trace`.
- **Validators** suite: completeness, rule alignment, toy causal, budget, window feasibility.
- **Repair** public taxonomy (`repair_categories`) and cross-package rules—**not** internal minimal-edit search code.
- **Toy abstract executor** with explicit illustrative indicators (`toy_executor.py`).
- **Visualization**: NetworkX layouts, white-background PNG pipeline suitable for supplementary PDFs.
- **Examples** and **`pytest`** suite; **negative** task package fixture for catalog validation.
- Documentation states boundaries versus **task intent compilation**, **RKG**, **staged planning**, **rule-consistent minimal-edit repair**, and **safe / abstract evaluation** in the full paper.

### Limitations (unchanged in spirit across patches)

- Toy executor and environment updates are **not** calibrated to operational simulators or paper proxy metrics.
- Some `data/topo_examples/` files may document **compact illustrative** graphs; **code generators** define full synthetic sizes per scale label.
- Layouts may shift slightly across Matplotlib/NetworkX versions for identical graphs; layout seeds are **explicit** in API where applicable.

### Maintenance

Bump **`schema_version`** and changelog entries together when schemas change incompatibly.
