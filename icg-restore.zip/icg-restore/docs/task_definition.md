# Task definition

## Intent versus package

The artifact models two artifacts consistent with **task intent compilation** and **staged planning** outputs at the **data** level:

1. **Task intent** (`task_intent.schema.json`) — Declarative fields: `goal`, `priority_objects`, `budget`, `time_window`, `constraints`, `completion_criteria`, optional `observations` and `rule_bounds`. This is **not** raw natural language from internal compilation logs.
2. **Task package** (`task_package.schema.json`) — Ordered **abstract primitives** with closed arguments, bound to `scenario_id` and `graph_id`.

Together they support readers who wish to inspect **structure** without accessing confidential prompts or proprietary plan stores.

## Task types (public identifiers)

`task_templates.py` defines:

- `backbone_path_recovery`
- `backup_path_activation`
- `core_service_recovery`
- `regional_access_coverage_recovery`

These names **align with manuscript task families**; **sampling distributions** and **instance IDs** from internal benchmarks are **not** redistributed.

## Rule bounds and validation

`rule_bounds` aligns budget, step caps, time window endpoints, forbidden primitives, and service priority strings with the validators in `repair/validation_rules.py` and `validators/`. This is a **public rule layer**—not the complete **rule-consistent minimal-edit repair** implementation from the full pipeline.

## Versioning

`schema_version` uses semantic `x.y.z` strings so supplementary bundles remain diffable across minor updates.
