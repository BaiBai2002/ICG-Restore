# Overview

## Purpose

This artifact gives reviewers and readers a **self-contained, auditable substrate** aligned with the ICG-Restore manuscript: it shows how **task intent compilation** (as reflected in structured intents and packages), a **heterogeneous scene graph** (topology JSON), environment dynamics, and validation hooks fit together at the **schema and reference-implementation level**. The design prioritizes **typed documents**, **explicit seeds**, and **journal-appropriate honesty** about what is and is not reproduced.

## Mapping to paper-stage concepts

| Manuscript stage (conceptual) | Representation in this artifact |
|-------------------------------|----------------------------------|
| Task intent compilation | `task_intent.schema.json`, `task/generation.py` (synthetic intents, not confidential templates) |
| Heterogeneous scene graph | `topology.schema.json`, `topology/build_topology.py` |
| Recovery knowledge graph (RKG) | **Not instantiated** as a separate engine; topology and task JSON are **compatible placeholders** for graph-aware reasoning at a **data-contract** level only |
| Staged planning | Task **packages** as ordered primitive lists; no LLM-driven stage machinery |
| Rule-consistent minimal-edit repair | `repair/repair_categories.py` (public **taxonomy**), `repair/validation_rules.py`, `validators/` (lightweight checks)—**not** the full internal repair search |
| Safe / proxy execution and abstract evaluation | `evaluation/toy_executor.py`, `evaluation/abstract_executor.py` (**toy** only; **not** the paper’s proxy executor or metric suite) |

## Repository map

- **`schemas/`** — Normative JSON Schema artifacts (`$id` URIs use a fixed namespace prefix; see `docs/schemas.md`).
- **`data/*_examples/`** — Minimal instances for tutorials and tests.
- **`src/icg_restore_artifact/`** — Reference code: generators, simulation, validation, visualization.
- **`examples/`** — Runnable demonstrations.
- **`docs/`** — Scope, limits, reproducibility.

## Intellectual boundary

Claims in the **peer-reviewed article** are supported by the **article text, its tables, and any explicitly linked evaluation materials** the authors register with the venue. **This repository supplements interpretation** of methods and data shapes; it does **not** by itself establish empirical conclusions.
