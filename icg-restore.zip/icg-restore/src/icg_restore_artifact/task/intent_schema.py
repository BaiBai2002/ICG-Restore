"""Pydantic views mirroring ``task_intent.schema.json`` (optional runtime typing)."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class BudgetModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    energy_units: int = Field(ge=0)
    max_primitive_steps: int = Field(ge=0)


class TimeWindowModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    start_unit: int
    end_unit: int


class PriorityObjectModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    object_kind: str
    reference_id: str
    rationale: str


class TaskIntentPublicModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str
    scenario_id: str
    task_type: str
    scale: str
    goal: str
    priority_objects: list[PriorityObjectModel] = Field(default_factory=list)
    budget: BudgetModel
    time_window: TimeWindowModel
    constraints: list[str] = Field(default_factory=list)
    completion_criteria: list[str] = Field(default_factory=list)
