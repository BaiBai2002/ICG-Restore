"""Synthetic task intent generation (public concepts only)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from icg_restore_artifact.config import DEFAULT_SCHEMA_VERSION, VALID_SCALES
from icg_restore_artifact.task import task_templates as tt
from icg_restore_artifact.utils.io_utils import write_json
from icg_restore_artifact.utils.random_utils import new_rng
from icg_restore_artifact.utils.schema_utils import validate_document

_GOALS: dict[str, str] = {
    tt.BACKBONE_PATH_RECOVERY: (
        "Re-establish a viable backbone path between designated coordination and edge access "
        "domains under degraded transport conditions."
    ),
    tt.BACKUP_PATH_ACTIVATION: (
        "Activate and commit traffic to designated backup logical dependencies while "
        "preserving core service continuity."
    ),
    tt.CORE_SERVICE_RECOVERY: (
        "Restore declared core service nodes to operational thresholds and reconcile "
        "dependent logical service-bearing edges."
    ),
    tt.REGIONAL_ACCESS_COVERAGE_RECOVERY: (
        "Improve regional access coverage metrics for prioritized clusters subject to "
        "energy and time limits."
    ),
}


def _budget_for_scale(scale: str, rng: Any) -> dict[str, int]:
    base = {"EC-S": (40, 10), "EC-M": (90, 18), "EC-L": (200, 36)}
    eu, ms = base[scale]
    jitter = rng.randint(-4, 6)
    return {
        "energy_units": max(10, eu + jitter),
        "max_primitive_steps": max(4, ms + rng.randint(-2, 3)),
    }


def _time_window(scale: str, rng: Any) -> dict[str, int]:
    span = {"EC-S": 24, "EC-M": 48, "EC-L": 96}[scale]
    start = rng.randint(0, 4)
    return {"start_unit": start, "end_unit": start + span}


def _priority_objects(task_type: str, scale: str, rng: Any) -> list[dict[str, str]]:
    objs: list[dict[str, str]] = [
        {
            "object_kind": "service",
            "reference_id": f"synthetic-svc-{rng.randint(1000, 9999)}",
            "rationale": "Primary service class referenced by the intent template.",
        },
        {
            "object_kind": "region",
            "reference_id": rng.choice(["R1", "R2", "R3"]),
            "rationale": "Geographic scope for coverage or isolation considerations.",
        },
    ]
    if task_type in (tt.BACKBONE_PATH_RECOVERY, tt.BACKUP_PATH_ACTIVATION):
        objs.insert(
            0,
            {
                "object_kind": "edge",
                "reference_id": f"synthetic-backbone-{scale}-{rng.randint(10, 99)}",
                "rationale": "Backbone or backup path segment prioritized for restoration.",
            },
        )
    else:
        objs.insert(
            0,
            {
                "object_kind": "node",
                "reference_id": f"synthetic-node-{rng.randint(10, 99)}",
                "rationale": "Critical node anchor for the declared objective.",
            },
        )
    return objs


def _constraints(task_type: str, rng: Any) -> list[str]:
    common = [
        "Abstract primitives only; no live-network execution.",
        "Respect declared budget and time window unless explicitly relaxed in metadata.",
    ]
    extra = {
        tt.BACKBONE_PATH_RECOVERY: [
            "Avoid simultaneous overload of all backbone gateways in a single step.",
        ],
        tt.BACKUP_PATH_ACTIVATION: [
            "Backup activation must not violate logical dependency ordering on core paths.",
        ],
        tt.CORE_SERVICE_RECOVERY: [
            "Core service recovery precedes opportunistic access expansion.",
        ],
        tt.REGIONAL_ACCESS_COVERAGE_RECOVERY: [
            "Regional coverage actions must remain consistent with channel mapping limits.",
        ],
    }[task_type]
    if rng.random() < 0.5:
        common.append("Observation noise may increase under delayed observation modes.")
    return common + extra


def _completion_criteria(task_type: str) -> list[str]:
    return [
        f"Objective for {task_type} satisfied under validator suite checks.",
        "Final abstract executor state meets toy feasibility thresholds where applicable.",
        "No forbidden primitives appear in the accepted package.",
    ]


def generate_task(task_type: str, scale: str, seed: int = 0) -> dict[str, Any]:
    """Create a synthetic task intent document validated against ``task_intent.schema.json``."""
    if task_type not in tt.ALL_TASK_TYPES:
        raise ValueError(f"unknown task_type {task_type!r}")
    if scale not in VALID_SCALES:
        raise ValueError(f"scale must be one of {VALID_SCALES}, got {scale!r}")
    rng = new_rng(seed)
    scenario_id = f"scn-{task_type}-{scale}-s{seed}"
    budget = _budget_for_scale(scale, rng)
    tw = _time_window(scale, rng)
    doc: dict[str, Any] = {
        "schema_version": DEFAULT_SCHEMA_VERSION,
        "scenario_id": scenario_id,
        "task_type": task_type,
        "scale": scale,
        "goal": _GOALS[task_type],
        "priority_objects": _priority_objects(task_type, scale, rng),
        "budget": budget,
        "time_window": tw,
        "constraints": _constraints(task_type, rng),
        "completion_criteria": _completion_criteria(task_type),
        "observations": [
            {
                "key": "synthetic_load_index",
                "value": f"{round(rng.uniform(0.2, 0.95), 3)}",
                "source": "synthetic_generator",
            }
        ],
        "rule_bounds": {
            "max_primitive_steps": budget["max_primitive_steps"],
            "energy_units": budget["energy_units"],
            "forbidden_primitives": [],
            "time_window_start_unit": tw["start_unit"],
            "time_window_end_unit": tw["end_unit"],
            "service_priority": ["voice", "data", "coordination"],
        },
    }
    validate_document("task_intent.schema.json", doc)
    return doc


def validate_task_intent(intent: dict[str, Any]) -> list[str]:
    """Return human-readable issues; empty means JSON Schema validation passed."""
    errors: list[str] = []
    try:
        validate_document("task_intent.schema.json", intent)
    except Exception as exc:
        return [str(exc)]
    tw = intent.get("time_window") or {}
    if isinstance(tw, dict) and tw.get("end_unit", 0) <= tw.get("start_unit", 0):
        errors.append("time_window end_unit must be greater than start_unit")
    b = intent.get("budget") or {}
    if isinstance(b, dict):
        if (b.get("energy_units") or 0) < 0 or (b.get("max_primitive_steps") or 0) < 0:
            errors.append("budget fields must be non-negative")
    return errors


def export_task_json(intent: dict[str, Any], path: Path | str, *, indent: int = 2) -> Path:
    """Write ``intent`` to JSON and return the resolved path."""
    out = Path(path)
    write_json(out, intent, indent=indent)
    return out.resolve()
