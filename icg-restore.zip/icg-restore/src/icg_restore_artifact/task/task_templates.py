"""Task-type identifiers aligned with public paper concepts."""

from __future__ import annotations

from typing import Final

BACKBONE_PATH_RECOVERY: Final[str] = "backbone_path_recovery"
BACKUP_PATH_ACTIVATION: Final[str] = "backup_path_activation"
CORE_SERVICE_RECOVERY: Final[str] = "core_service_recovery"
REGIONAL_ACCESS_COVERAGE_RECOVERY: Final[str] = "regional_access_coverage_recovery"

ALL_TASK_TYPES: Final[tuple[str, ...]] = (
    BACKBONE_PATH_RECOVERY,
    BACKUP_PATH_ACTIVATION,
    CORE_SERVICE_RECOVERY,
    REGIONAL_ACCESS_COVERAGE_RECOVERY,
)


def list_task_types() -> tuple[str, ...]:
    return ALL_TASK_TYPES
