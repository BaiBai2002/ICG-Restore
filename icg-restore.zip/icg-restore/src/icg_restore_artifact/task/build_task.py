"""Construct validated task packages linked to synthetic topologies."""

from __future__ import annotations

from typing import Any

from icg_restore_artifact.config import DEFAULT_SCHEMA_VERSION
from icg_restore_artifact.utils.schema_utils import validate_document


def build_task_package(
    *,
    package_id: str,
    scenario_id: str,
    graph_id: str,
    primitives: list[dict[str, Any]],
    task_type: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    doc = {
        "schema_version": DEFAULT_SCHEMA_VERSION,
        "package_id": package_id,
        "scenario_id": scenario_id,
        "graph_id": graph_id,
        "topology_id": graph_id,
        "task_type": task_type,
        "primitives": primitives,
        "metadata": metadata or {},
    }
    validate_document("task_package.schema.json", doc)
    return doc
