"""Minimal-edit repair specifications, public categories, and cross-package rules."""

from icg_restore_artifact.repair.minimal_edit_spec import EditKind, MinimalEdit
from icg_restore_artifact.repair.repair_categories import (
    PublicRepairCategory,
    RepairCategorySpec,
    list_repair_category_specs,
    repair_categories_as_json,
)
from icg_restore_artifact.repair.validation_rules import (
    validate_package_against_intent,
    validate_primitive_catalog,
)

__all__ = [
    "EditKind",
    "MinimalEdit",
    "PublicRepairCategory",
    "RepairCategorySpec",
    "list_repair_category_specs",
    "repair_categories_as_json",
    "validate_package_against_intent",
    "validate_primitive_catalog",
]
