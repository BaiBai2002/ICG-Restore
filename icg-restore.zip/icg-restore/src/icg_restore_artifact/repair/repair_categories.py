"""
Public documentation of minimal-edit repair *categories* (descriptive spec).

These categories explain common plan defects addressed by minimal-edit repair in the
paper narrative. This module does **not** ship confidential scoring, prioritization,
or internal repair policies—only structured descriptions and toy illustrations.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class PublicRepairCategory(str, Enum):
    MISSING_PREREQUISITE = "missing_prerequisite"
    STAGE_ORDER_CONFLICT = "stage_order_conflict"
    ACTION_TARGET_MISMATCH = "action_target_mismatch"
    BUDGET_OVERFLOW = "budget_overflow"
    TIME_WINDOW_CONFLICT = "time_window_conflict"


class RepairCategorySpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    category: PublicRepairCategory
    summary: str
    detection_hints: list[str] = Field(default_factory=list)
    toy_example: dict[str, Any] = Field(default_factory=dict)


def list_repair_category_specs() -> tuple[RepairCategorySpec, ...]:
    return (
        RepairCategorySpec(
            category=PublicRepairCategory.MISSING_PREREQUISITE,
            summary=(
                "A planned action assumes a resource or node state that has not been established "
                "by earlier steps (e.g., link restoration before endpoint activation)."
            ),
            detection_hints=[
                "Compare primitive preconditions against the partially executed abstract state.",
                "Flag unknown node or edge references in arguments.",
            ],
            toy_example={
                "primitives": [
                    {"name": "restore_link", "args": {"edge_id": "e-example"}},
                ],
                "deficit": "Endpoints never received activate_node in prior steps.",
            },
        ),
        RepairCategorySpec(
            category=PublicRepairCategory.STAGE_ORDER_CONFLICT,
            summary=(
                "Actions appear in an order inconsistent with declared staging or dependency layers "
                "(e.g., regional expansion before core stabilization when constraints forbid it)."
            ),
            detection_hints=[
                "Scan for monotonic stage tags implied by constraints strings versus step order.",
            ],
            toy_example={
                "constraint": "Core service recovery precedes opportunistic access expansion.",
                "primitives": [
                    {"name": "schedule_survey", "args": {"region": "R2"}},
                    {"name": "activate_node", "args": {"node_id": "cs-0"}},
                ],
            },
        ),
        RepairCategorySpec(
            category=PublicRepairCategory.ACTION_TARGET_MISMATCH,
            summary=(
                "An action targets an object incompatible with intent priority_objects or graph role "
                "(e.g., channel action on an access cluster when priority references backbone)."
            ),
            detection_hints=[
                "Align reference_id entries from intent.priority_objects with graph node/edge roles.",
            ],
            toy_example={
                "priority": {"object_kind": "edge", "reference_id": "e-backbone-1"},
                "primitive": {"name": "clear_fault_flag", "args": {"node_id": "ac-0"}},
            },
        ),
        RepairCategorySpec(
            category=PublicRepairCategory.BUDGET_OVERFLOW,
            summary="Planned steps or implied energy use exceed intent.budget or rule_bounds.",
            detection_hints=[
                "Apply public budget_feasibility checks with documented per-step cost assumptions.",
            ],
            toy_example={
                "budget": {"energy_units": 2, "max_primitive_steps": 5},
                "plan_length": 9,
            },
        ),
        RepairCategorySpec(
            category=PublicRepairCategory.TIME_WINDOW_CONFLICT,
            summary=(
                "The implied schedule length exceeds intent.time_window span under published timing assumptions."
            ),
            detection_hints=[
                "Use window_feasibility helpers with explicit time_units_per_primitive.",
            ],
            toy_example={
                "time_window": {"start_unit": 0, "end_unit": 6},
                "estimated_need": 8,
            },
        ),
    )


def repair_categories_as_json() -> list[dict[str, Any]]:
    return [spec.model_dump(mode="json") for spec in list_repair_category_specs()]
