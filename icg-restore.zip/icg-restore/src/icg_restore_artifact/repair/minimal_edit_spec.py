"""Declarative description of minimal-edit operations (conceptual layer).

Full repair search over candidate plans is not bundled in this artifact; the
types below document the operations that validators and demos refer to.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class EditKind(str, Enum):
    INSERT_STEP = "insert_step"
    DELETE_STEP = "delete_step"
    REORDER = "reorder"
    PATCH_ARGS = "patch_args"


class MinimalEdit(BaseModel):
    model_config = ConfigDict(extra="forbid")

    kind: EditKind
    index: int | None = None
    primitive: dict[str, Any] | None = None
    note: str = ""
