"""Cross-document validation (intent bounds versus declared packages)."""

from __future__ import annotations

from typing import Any


def _max_primitive_steps(intent: dict[str, Any]) -> int | None:
    bud = intent.get("budget") or {}
    if isinstance(bud, dict):
        ms = bud.get("max_primitive_steps")
        if isinstance(ms, int):
            return ms
    rb = intent.get("rule_bounds") or {}
    ms = rb.get("max_primitive_steps")
    return ms if isinstance(ms, int) else None


def validate_package_against_intent(intent: dict[str, Any], package: dict[str, Any]) -> list[str]:
    """Return human-readable violation messages; empty list means pass."""
    errors: list[str] = []
    if intent.get("scenario_id") != package.get("scenario_id"):
        errors.append("scenario_id mismatch between intent and package")
    topo_id = intent.get("graph_id")
    if isinstance(topo_id, str) and package.get("graph_id") and package["graph_id"] != topo_id:
        errors.append("graph_id mismatch between intent attachment and package")
    max_steps = _max_primitive_steps(intent)
    primitives = package.get("primitives") or []
    if isinstance(max_steps, int) and len(primitives) > max_steps:
        errors.append(f"primitive count {len(primitives)} exceeds max_primitive_steps {max_steps}")

    rb = intent.get("rule_bounds") or {}
    forbidden = set(rb.get("forbidden_primitives") or [])
    for i, step in enumerate(primitives):
        name = step.get("name")
        if name in forbidden:
            errors.append(f"step {i} uses forbidden primitive {name!r}")
    return errors


def allowed_primitive_names() -> frozenset[str]:
    """Closed-world catalog for toy executor and demos."""
    return frozenset(
        {
            "activate_node",
            "restore_link",
            "reroute_flow",
            "schedule_survey",
            "clear_fault_flag",
        }
    )


def validate_primitive_catalog(package: dict[str, Any]) -> list[str]:
    """Ensure each primitive name appears in the toy catalog."""
    allowed = allowed_primitive_names()
    errors: list[str] = []
    for i, step in enumerate(package.get("primitives") or []):
        name = step.get("name")
        if name not in allowed:
            errors.append(f"step {i} unknown primitive {name!r} (not in toy catalog)")
    return errors
