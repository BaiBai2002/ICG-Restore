"""
**Toy / illustrative** abstract executor for the public artifact only.

This module does **not** reproduce the full paper evaluation engine, proxy metrics,
or confidential internal validation. It applies the same small primitive catalog as
``AbstractExecutor`` and reports **pedagogical indicators** derived from before/after
state snapshots over a synthetic topology.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from icg_restore_artifact.evaluation.abstract_executor import AbstractExecutor, ExecutorState, StepRecord


class ToyIndicatorReport(BaseModel):
    """Illustrative scalar summaries (not paper-reported metrics)."""

    model_config = ConfigDict(extra="forbid")

    illustrative_only: bool = True
    path_restoration_gain: float = Field(description="Mean residual on physical connectivity edges, after − before.")
    service_recovery_gain: float = Field(description="Avg availability on Core Service nodes, after − before.")
    coverage_gain: float = Field(description="Avg availability on Access Cluster nodes, after − before.")
    coordination_delay_change: float = Field(
        description="Synthetic coordination delay delta (abstract time units; increases with plan length)."
    )


def _mean_physical_residual(state: ExecutorState, topology: dict[str, Any]) -> float:
    phys_eids = {
        str(e["id"])
        for e in topology.get("edges", [])
        if str(e.get("type")) == "physical_connectivity"
    }
    if not phys_eids:
        vals = list(state.edge_residual_capacity.values())
        return sum(vals) / len(vals) if vals else 0.0
    vals = [state.edge_residual_capacity.get(eid, 0.0) for eid in phys_eids]
    return sum(vals) / len(vals)


def _mean_avail_for_node_type(state: ExecutorState, topology: dict[str, Any], ntype: str) -> float:
    ids = [str(n["id"]) for n in topology.get("nodes", []) if str(n.get("type")) == ntype]
    if not ids:
        return 0.0
    return sum(state.node_availability.get(i, 0.0) for i in ids) / len(ids)


def initial_executor_state_from_topology(topology: dict[str, Any]) -> ExecutorState:
    """Seed toy availability and edge residuals from topology attributes (degraded baseline)."""
    node_availability: dict[str, float] = {}
    for n in topology.get("nodes", []):
        nid = str(n["id"])
        attrs = n.get("attributes") or {}
        status = float(attrs.get("operational_status", 0.45))
        node_availability[nid] = max(0.05, min(0.95, status * 0.35))
    edge_residual_capacity = {}
    for e in topology.get("edges", []):
        eid = str(e["id"])
        attrs = e.get("attributes") or {}
        cap = float(attrs.get("residual_capacity", 0.3))
        edge_residual_capacity[eid] = max(0.05, min(0.95, cap * 0.45))
    return ExecutorState(node_availability=node_availability, edge_residual_capacity=edge_residual_capacity)


def run_toy_executor(
    topology: dict[str, Any],
    package: dict[str, Any],
) -> tuple[ExecutorState, ToyIndicatorReport, list[StepRecord]]:
    """
    Run the toy primitive sequence and return (final_state, indicators).

    **Illustrative only** — not equivalent to the paper's evaluation stack.
    """
    before_state = initial_executor_state_from_topology(topology)
    path_before = _mean_physical_residual(before_state, topology)
    svc_before = _mean_avail_for_node_type(before_state, topology, "Core Service Node")
    cov_before = _mean_avail_for_node_type(before_state, topology, "Access Cluster")

    executor = AbstractExecutor(before_state.model_copy(deep=True))
    steps = executor.run_package(package)
    after = executor.state

    path_after = _mean_physical_residual(after, topology)
    svc_after = _mean_avail_for_node_type(after, topology, "Core Service Node")
    cov_after = _mean_avail_for_node_type(after, topology, "Access Cluster")

    prim_count = len(package.get("primitives") or [])
    delay_delta = 0.04 * prim_count
    for step in package.get("primitives") or []:
        if step.get("name") == "schedule_survey":
            delay_delta -= 0.02

    report = ToyIndicatorReport(
        path_restoration_gain=round(path_after - path_before, 4),
        service_recovery_gain=round(svc_after - svc_before, 4),
        coverage_gain=round(cov_after - cov_before, 4),
        coordination_delay_change=round(delay_delta, 4),
    )
    return after, report, steps
