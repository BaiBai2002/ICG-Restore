"""Heuristic abstract executor (non-operational semantics)."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ExecutorState(BaseModel):
    model_config = ConfigDict(extra="forbid")

    node_availability: dict[str, float] = Field(default_factory=dict)
    edge_residual_capacity: dict[str, float] = Field(default_factory=dict)


class StepRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    primitive_name: str
    state_before_digest: str
    state_after_digest: str


def _digest_state(state: ExecutorState) -> str:
    payload = state.model_dump(mode="json", sort_keys=True)
    raw = json.dumps(payload, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


class AbstractExecutor:
    """Apply the public **toy** primitive catalog to ``ExecutorState`` (illustration only)."""

    def __init__(self, initial: ExecutorState) -> None:
        self.state = initial

    def run_package(self, package: dict[str, Any]) -> list[StepRecord]:
        records: list[StepRecord] = []
        for step in package.get("primitives") or []:
            name = str(step.get("name", ""))
            args = step.get("args") or {}
            before = _digest_state(self.state)
            self._apply(name, args)
            after = _digest_state(self.state)
            records.append(
                StepRecord(primitive_name=name, state_before_digest=before, state_after_digest=after)
            )
        return records

    def _apply(self, name: str, args: dict[str, Any]) -> None:
        if name == "activate_node":
            nid = str(args.get("node_id", ""))
            level = float(args.get("power_level", 1.0))
            cur = self.state.node_availability.get(nid, 0.0)
            self.state.node_availability[nid] = min(1.0, max(cur, level))
        elif name == "restore_link":
            eid = str(args.get("edge_id", ""))
            target = float(args.get("target_utilization", 0.8))
            cur = self.state.edge_residual_capacity.get(eid, 0.0)
            self.state.edge_residual_capacity[eid] = min(1.0, max(cur, target))
        elif name == "reroute_flow":
            eid = str(args.get("edge_id", ""))
            bump = float(args.get("bump", 0.1))
            if eid:
                cur = self.state.edge_residual_capacity.get(eid, 0.0)
                self.state.edge_residual_capacity[eid] = min(1.0, cur + bump)
        elif name == "schedule_survey":
            pass
        elif name == "clear_fault_flag":
            nid = str(args.get("node_id", ""))
            if nid:
                self.state.node_availability[nid] = min(1.0, self.state.node_availability.get(nid, 0.0) + 0.1)
        else:
            raise ValueError(f"unsupported primitive in toy executor: {name!r}")
