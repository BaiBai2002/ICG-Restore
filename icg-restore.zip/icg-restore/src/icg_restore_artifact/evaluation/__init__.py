"""Toy abstract executor and illustrative metrics (not the paper evaluation engine)."""

from icg_restore_artifact.evaluation.abstract_executor import AbstractExecutor, ExecutorState, StepRecord
from icg_restore_artifact.evaluation.toy_executor import (
    ToyIndicatorReport,
    initial_executor_state_from_topology,
    run_toy_executor,
)
from icg_restore_artifact.evaluation.toy_metrics import summarize_run

__all__ = [
    "AbstractExecutor",
    "ExecutorState",
    "StepRecord",
    "ToyIndicatorReport",
    "initial_executor_state_from_topology",
    "run_toy_executor",
    "summarize_run",
]
