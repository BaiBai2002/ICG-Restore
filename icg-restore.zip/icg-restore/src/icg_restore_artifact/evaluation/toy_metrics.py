"""Pedagogical metrics for toy executor runs (not paper aggregates)."""

from __future__ import annotations

from typing import Any

from icg_restore_artifact.evaluation.abstract_executor import ExecutorState, StepRecord


def _max_steps_intent(intent: dict[str, Any]) -> int | None:
    bud = intent.get("budget") or {}
    if isinstance(bud, dict):
        ms = bud.get("max_primitive_steps")
        if isinstance(ms, int):
            return ms
    rb = intent.get("rule_bounds") or {}
    ms = rb.get("max_primitive_steps")
    return ms if isinstance(ms, int) else None


def summarize_run(
    *,
    final_state: ExecutorState,
    steps: list[StepRecord],
    intent: dict[str, Any],
) -> dict[str, Any]:
    """Return a small JSON-serializable summary for demos and tests."""
    prim_count = len(steps)
    max_steps = _max_steps_intent(intent)
    within_steps = True
    if isinstance(max_steps, int):
        within_steps = prim_count <= max_steps
    min_avail = min(final_state.node_availability.values(), default=1.0)
    min_edge = min(final_state.edge_residual_capacity.values(), default=1.0)
    return {
        "primitive_count": prim_count,
        "within_step_budget": within_steps,
        "min_node_availability": min_avail,
        "min_edge_residual": min_edge,
        "feasibility_toy": bool(within_steps and min_avail >= 0.5 and min_edge >= 0.5),
    }
