"""Task / plan visualization as a directed primitive chain (NetworkX + Matplotlib)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import networkx as nx

__all__ = ["plot_task_graph", "save_task_graph"]


def plot_task_graph(task: dict[str, Any], save_path: Path | str, *, layout_seed: int = 1) -> Path:
    """
    Plot a linear primitive sequence.

    ``task`` is typically a **task package** (``primitives`` list). If only an intent
    is supplied, primitives may be empty and a single diagrammatic 'empty plan' node is drawn.
    """
    path = Path(save_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    steps = list(task.get("primitives") or [])

    G = nx.DiGraph()
    if not steps:
        G.add_node("empty", label="(no primitives)")
    else:
        for i, step in enumerate(steps):
            nid = f"s{i}"
            name = str(step.get("name", "?"))
            G.add_node(nid, label=name)
            if i > 0:
                G.add_edge(f"s{i - 1}", nid)

    pos = nx.spring_layout(G, seed=layout_seed, k=1.8)

    fig, ax = plt.subplots(figsize=(max(8, len(steps) * 1.1), 3.2), dpi=150, facecolor="white")
    ax.set_facecolor("white")

    labels = nx.get_node_attributes(G, "label")
    nx.draw_networkx_nodes(G, pos, ax=ax, node_color="#e0e7ff", edgecolors="#312e81", node_size=2600)
    nx.draw_networkx_labels(G, pos, labels, ax=ax, font_size=8, font_color="#1e1b4b")
    nx.draw_networkx_edges(
        G, pos, ax=ax, edge_color="#475569", arrows=True, arrowsize=18, width=1.4, node_size=2600
    )

    pid = task.get("package_id", task.get("scenario_id", ""))
    ax.set_title(f"Task package — primitive chain\n{pid}", fontsize=11, color="#111827")
    ax.axis("off")
    plt.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white", edgecolor="none", pad_inches=0.1)
    plt.close(fig)
    return path.resolve()


def save_task_graph(package: dict[str, Any], path: Path) -> None:
    plot_task_graph(package, path)
