"""Publication-quality topology figures (NetworkX layout + Matplotlib)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import networkx as nx

from icg_restore_artifact.visualization import styles

__all__ = ["plot_topology", "save_topology_figure"]


def plot_topology(graph: dict[str, Any], save_path: Path | str, *, layout_seed: int = 42) -> Path:
    """
    Render a synthetic scene graph (topology document) to PNG.

    White background, distinct node and edge encodings suitable for README
    and journal supplementary material.
    """
    path = Path(save_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    G = nx.Graph()
    node_labels: dict[str, str] = {}
    node_types: dict[str, str] = {}
    for n in graph.get("nodes", []):
        nid = str(n["id"])
        ntype = str(n.get("type", ""))
        G.add_node(nid)
        node_types[nid] = ntype
        short = str(n.get("label", nid))
        if len(short) > 18:
            short = short[:16] + "…"
        node_labels[nid] = short

    for e in graph.get("edges", []):
        u, v = str(e["source"]), str(e["target"])
        etype = str(e.get("type", "physical_connectivity"))
        if G.has_edge(u, v):
            continue
        G.add_edge(u, v, edge_type=etype)

    if G.number_of_nodes() == 0:
        fig, ax = plt.subplots(figsize=(6, 4), dpi=120, facecolor="white")
        ax.text(0.5, 0.5, "(empty graph)", ha="center", va="center")
        ax.axis("off")
        fig.savefig(path, facecolor="white", bbox_inches="tight")
        plt.close(fig)
        return path.resolve()

    pos = nx.spring_layout(
        G,
        seed=layout_seed,
        k=2.6 / max(1, G.number_of_nodes()) ** 0.5,
        iterations=88,
    )
    fig, ax = plt.subplots(figsize=(10, 7), dpi=150, facecolor="white")
    ax.set_facecolor("white")

    for etype, spec in styles.EDGE_DRAW.items():
        elist = [(u, v) for u, v, d in G.edges(data=True) if d.get("edge_type") == etype]
        if not elist:
            continue
        nx.draw_networkx_edges(
            G,
            pos,
            edgelist=elist,
            ax=ax,
            edge_color=spec["color"],
            style=spec["style"],
            width=spec["width"],
            arrows=False,
        )

    colors = [styles.NODE_FACE.get(node_types[n], styles.DEFAULT_NODE_FACE) for n in G.nodes()]
    nx.draw_networkx_nodes(
        G,
        pos,
        ax=ax,
        node_color=colors,
        edgecolors=styles.NODE_EDGE_COLOR,
        linewidths=1.2,
        node_size=920,
    )
    nx.draw_networkx_labels(
        G,
        pos,
        labels=node_labels,
        ax=ax,
        font_size=7,
        font_color="white",
        font_weight="medium",
    )

    scale = graph.get("scale", "")
    gid = graph.get("graph_id", "")
    ax.set_title(f"ICG-Restore artifact — synthetic topology ({scale})\n{gid}", fontsize=11, color="#111827")
    ax.axis("off")
    ax.set_aspect("equal")
    plt.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white", edgecolor="none", pad_inches=0.12)
    plt.close(fig)
    return path.resolve()


def save_topology_figure(topology: dict[str, Any], path: Path, *, seed: int = 0) -> None:
    """Backward-compatible alias; ``seed`` maps to layout seed."""
    plot_topology(topology, path, layout_seed=seed)
