"""Publication-oriented colors and line styles for topology figures."""

from __future__ import annotations

from typing import Any

NODE_FACE: dict[str, str] = {
    "Coordination Center": "#1d4ed8",
    "Backbone Gateway": "#0d9488",
    "Core Service Node": "#7c3aed",
    "Relay Node": "#d97706",
    "Access Cluster": "#dc2626",
    "Channel Resource": "#4b5563",
}

NODE_EDGE_COLOR = "#1f2937"
DEFAULT_NODE_FACE = "#6b7280"

EDGE_DRAW: dict[str, dict[str, Any]] = {
    "physical_connectivity": {"color": "#374151", "style": "solid", "width": 1.6},
    "logical_dependency": {"color": "#6d28d9", "style": "dashed", "width": 1.4},
    "service_bearing": {"color": "#b45309", "style": "solid", "width": 1.2},
    "channel_mapping": {"color": "#0369a1", "style": "dashdot", "width": 1.3},
}
