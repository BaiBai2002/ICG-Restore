"""Render bundled supplementary figures into ``data/visualization/``."""

from __future__ import annotations

from pathlib import Path

from icg_restore_artifact.config import data_dir
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.visualization.plot_pipeline_overview import plot_pipeline_overview
from icg_restore_artifact.visualization.plot_topology import plot_topology


def export_topology_figures_for_scales(
    base_dir: Path | None = None,
    *,
    layout_seed: int = 42,
) -> dict[str, Path]:
    out: dict[str, Path] = {}
    root = Path(base_dir) if base_dir is not None else data_dir() / "visualization"
    for scale, fname in (("EC-S", "EC-S_topology.png"), ("EC-M", "EC-M_topology.png"), ("EC-L", "EC-L_topology.png")):
        topo = build_topology(scale, seed=0)
        jitter = sum(ord(c) for c in scale) % 50
        path = plot_topology(topo, root / fname, layout_seed=layout_seed + jitter)
        out[fname] = path
    return out


def export_pipeline_overview_figure(base_dir: Path | None = None) -> Path:
    root = Path(base_dir) if base_dir is not None else data_dir() / "visualization"
    return plot_pipeline_overview(root / "pipeline_overview.png")


def export_all_publication_figures(base_dir: Path | None = None) -> dict[str, Path]:
    paths = {k: v for k, v in export_topology_figures_for_scales(base_dir=base_dir).items()}
    paths["pipeline_overview.png"] = export_pipeline_overview_figure(base_dir=base_dir)
    return paths
