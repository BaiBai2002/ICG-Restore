"""Artifact pipeline overview figure for supplementary documentation."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

__all__ = ["plot_pipeline_overview", "save_pipeline_overview"]


def plot_pipeline_overview(save_path: Path | str) -> Path:
    """High-level ICG-Restore public artifact flow; white background, vector-friendly styling."""
    path = Path(save_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(10, 4.2), dpi=150, facecolor="white")
    ax.set_facecolor("white")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 5)
    ax.axis("off")

    boxes = [
        (0.3, 3.1, 1.5, 1.1, "Topology\nconstruction"),
        (2.2, 3.1, 1.5, 1.1, "Task\ngeneration"),
        (4.1, 3.1, 1.5, 1.1, "Validation\nsuite"),
        (6.0, 3.1, 1.5, 1.1, "Environment\nsimulation"),
        (3.6, 1.0, 2.4, 1.1, "Toy abstract executor\n(illustrative metrics only)"),
        (6.6, 1.0, 1.5, 1.1, "Figures\nexport"),
    ]

    for x, y, w, h, text in boxes:
        patch = FancyBboxPatch(
            (x, y),
            w,
            h,
            boxstyle="round,pad=0.04,rounding_size=0.08",
            facecolor="#f8fafc",
            edgecolor="#0f172a",
            linewidth=1.2,
        )
        ax.add_patch(patch)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9, color="#0f172a")

    arrows = [
        (1.8, 3.65, 2.15, 3.65),
        (3.7, 3.65, 4.05, 3.65),
        (5.6, 3.65, 5.95, 3.65),
        (4.95, 3.1, 4.8, 2.15),
        (5.2, 3.1, 5.5, 2.15),
        (7.35, 3.1, 7.35, 2.15),
        (8.2, 1.55, 8.8, 1.55),
    ]
    for x1, y1, x2, y2 in arrows:
        arr = FancyArrowPatch(
            (x1, y1),
            (x2, y2),
            arrowstyle="-|>",
            mutation_scale=14,
            linewidth=1.2,
            color="#334155",
            shrinkA=4,
            shrinkB=4,
        )
        ax.add_patch(arr)

    ax.text(
        5,
        4.75,
        "ICG-Restore public artifact — end-to-end demonstration flow",
        ha="center",
        fontsize=12,
        fontweight="600",
        color="#0f172a",
    )

    legend_elems = [
        mpatches.Patch(facecolor="#f8fafc", edgecolor="#0f172a", label="Pipeline stage"),
    ]
    ax.legend(handles=legend_elems, loc="lower left", frameon=False, fontsize=8)

    plt.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white", edgecolor="none", pad_inches=0.15)
    plt.close(fig)
    return path.resolve()


def save_pipeline_overview(path: Path) -> None:
    plot_pipeline_overview(path)
