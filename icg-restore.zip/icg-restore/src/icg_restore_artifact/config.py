"""Artifact-wide paths and default constants."""

from __future__ import annotations

from pathlib import Path
from typing import Final

from pydantic import BaseModel, ConfigDict, Field


def artifact_root() -> Path:
    """Return the repository root (directory containing ``schemas/`` and ``data/``)."""
    return Path(__file__).resolve().parent.parent.parent


def schemas_dir() -> Path:
    return artifact_root() / "schemas"


def data_dir() -> Path:
    return artifact_root() / "data"


DEFAULT_SCHEMA_VERSION: Final[str] = "0.2.0"

VALID_SCALES: Final[tuple[str, ...]] = ("EC-S", "EC-M", "EC-L")


class ScaleProfile(BaseModel):
    model_config = ConfigDict(extra="forbid")
    backbone_gateways: int = Field(ge=1)
    core_services: int = Field(ge=1)
    relay_nodes: int = Field(ge=1)
    access_clusters: int = Field(ge=1)
    channel_resources: int = Field(ge=1)


SCALE_PROFILES: dict[str, ScaleProfile] = {
    "EC-S": ScaleProfile(
        backbone_gateways=2,
        core_services=2,
        relay_nodes=3,
        access_clusters=2,
        channel_resources=2,
    ),
    "EC-M": ScaleProfile(
        backbone_gateways=4,
        core_services=5,
        relay_nodes=10,
        access_clusters=6,
        channel_resources=4,
    ),
    "EC-L": ScaleProfile(
        backbone_gateways=8,
        core_services=12,
        relay_nodes=28,
        access_clusters=15,
        channel_resources=10,
    ),
}


class GeneratorDefaults(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topology_prefix: str = Field(default="synthetic")
    default_seed: int = Field(default=0)


GENERATOR_DEFAULTS = GeneratorDefaults()
