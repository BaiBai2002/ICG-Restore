"""Write lightweight synthetic examples under ``data/*_examples/`` for the repository."""

from __future__ import annotations

from pathlib import Path

from icg_restore_artifact.config import data_dir
from icg_restore_artifact.environment.simulation import export_environment_trace, generate_environment_trace
from icg_restore_artifact.task.generation import export_task_json, generate_task
from icg_restore_artifact.task.task_templates import ALL_TASK_TYPES
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.topology.topology_export import export_topology_json
from icg_restore_artifact.utils.io_utils import write_json
from icg_restore_artifact.utils.schema_utils import validate_document


def export_default_examples(
    *,
    base: Path | None = None,
    topology_scales: tuple[str, ...] = ("EC-S", "EC-M", "EC-L"),
    task_scale: str = "EC-S",
    task_seed: int = 0,
    trace_length: int = 8,
    trace_seed: int = 42,
) -> dict[str, list[str]]:
    """
    Generate and validate example JSON files. Returns a map category -> written paths.
    """
    root = Path(base) if base is not None else data_dir()
    written: dict[str, list[str]] = {"topology": [], "task": [], "environment": []}

    for scale in topology_scales:
        topo = build_topology(scale, seed=0)
        fname = f"topology_{scale.lower().replace('-', '')}_seed0.json"
        path = root / "topo_examples" / fname
        export_topology_json(topo, path)
        validate_document("topology.schema.json", topo)
        written["topology"].append(str(path))

    for tt in ALL_TASK_TYPES:
        intent = generate_task(tt, task_scale, task_seed)
        path = root / "task_examples" / f"intent_{tt}.json"
        export_task_json(intent, path)
        validate_document("task_intent.schema.json", intent)
        written["task"].append(str(path))

    topo_small = build_topology("EC-S", seed=1)
    trace = generate_environment_trace(
        length=trace_length,
        seed=trace_seed,
        trace_id="trace_synthetic_seed42",
        topology=topo_small,
        graph_id=topo_small["graph_id"],
    )
    trace_path = root / "env_examples" / "environment_trace_seed42.json"
    export_environment_trace(trace, trace_path)
    validate_document("environment_trace.schema.json", trace)
    written["environment"].append(str(trace_path))

    sample_event = trace["steps"][0]["event"]
    event_path = root / "env_examples" / "environment_event_sample.json"
    write_json(event_path, sample_event)
    validate_document("environment_event.schema.json", sample_event)
    written["environment"].append(str(event_path))

    return written


def main() -> None:
    summary = export_default_examples()
    for category, paths in summary.items():
        print(category)
        for p in paths:
            print(f"  {p}")


if __name__ == "__main__":
    main()
