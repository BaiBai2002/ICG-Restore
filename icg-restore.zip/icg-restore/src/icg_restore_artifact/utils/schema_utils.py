"""Load JSON Schema files and validate documents."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from icg_restore_artifact.config import schemas_dir


def schema_path(name: str) -> Path:
    if not name.endswith(".json"):
        name = f"{name}.schema.json"
    return schemas_dir() / name


def load_validator(schema_filename: str) -> Draft202012Validator:
    path = schema_path(schema_filename)
    raw = json.loads(path.read_text(encoding="utf-8"))
    return Draft202012Validator(raw)


def validate_document(schema_filename: str, instance: Any) -> None:
    """Validate ``instance`` against a schema in ``schemas/``; raise on failure."""
    validator = load_validator(schema_filename)
    validator.validate(instance)
