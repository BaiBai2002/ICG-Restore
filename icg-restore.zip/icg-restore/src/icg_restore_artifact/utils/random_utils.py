"""Deterministic randomness without NumPy (cross-platform stability for toy code)."""

from __future__ import annotations

import random


def new_rng(seed: int) -> random.Random:
    return random.Random(seed)
