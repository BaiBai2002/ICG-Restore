"""Write a small JSON bundle for supplementary archives."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from icg_restore_artifact.demo.demo_pipeline import run_toy_demo
from icg_restore_artifact.utils.io_utils import write_json


def export_bundle(
    directory: Path,
    *,
    seed: int = 42,
    visualization_path: Path | str | None = None,
) -> Path:
    directory = Path(directory)
    result = run_toy_demo(seed=seed, visualization_path=visualization_path)
    out = directory / "demo_bundle.json"
    slim: dict[str, Any] = {
        "schema_note": "Artifact toy bundle; not a paper-scale benchmark instance.",
        "seed": result["seed"],
        "graph_id": result["topology"]["graph_id"],
        "metrics": result["metrics"],
        "toy_indicators": result["toy_indicators"],
        "validation_cross": result["validation_cross"],
        "validation_catalog": result["validation_catalog"],
        "validator_suite": result["validator_suite"],
        "visualization_path": result["visualization_path"],
    }
    write_json(out, slim)
    return out
