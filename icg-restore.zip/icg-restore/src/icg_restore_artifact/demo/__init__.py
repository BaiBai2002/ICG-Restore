"""Demonstration entry points."""

from icg_restore_artifact.demo.demo_pipeline import run_toy_demo
from icg_restore_artifact.demo.export_demo_bundle import export_bundle

__all__ = ["run_toy_demo", "export_bundle"]
