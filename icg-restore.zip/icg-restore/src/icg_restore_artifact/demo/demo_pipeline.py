"""Orchestrate a seed-stable toy demonstration (no external services)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from icg_restore_artifact.environment.modes import STABLE_RECOVERY
from icg_restore_artifact.environment.simulation import (
    build_initial_simulation_state,
    generate_environment_trace,
    simulate_env_step,
)
from icg_restore_artifact.evaluation.toy_executor import run_toy_executor
from icg_restore_artifact.evaluation.toy_metrics import summarize_run
from icg_restore_artifact.repair.validation_rules import validate_package_against_intent, validate_primitive_catalog
from icg_restore_artifact.task.build_task import build_task_package
from icg_restore_artifact.task.generation import generate_task
from icg_restore_artifact.task.task_templates import REGIONAL_ACCESS_COVERAGE_RECOVERY
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.utils.schema_utils import validate_document
from icg_restore_artifact.validators.suite import run_validator_suite


def _primitives_for_physical_edge(topology: dict[str, Any]) -> list[dict[str, Any]]:
    for edge in topology.get("edges", []):
        if edge.get("type") == "physical_connectivity":
            u, v = edge["source"], edge["target"]
            eid = edge["id"]
            return [
                {"name": "activate_node", "args": {"node_id": u, "power_level": 0.9}},
                {"name": "activate_node", "args": {"node_id": v, "power_level": 0.88}},
                {"name": "restore_link", "args": {"edge_id": eid, "target_utilization": 0.72}},
            ]
    edge = topology["edges"][0]
    u, v = edge["source"], edge["target"]
    return [
        {"name": "activate_node", "args": {"node_id": u, "power_level": 0.9}},
        {"name": "activate_node", "args": {"node_id": v, "power_level": 0.88}},
        {"name": "restore_link", "args": {"edge_id": edge["id"], "target_utilization": 0.72}},
    ]


def run_toy_demo(
    *,
    seed: int = 42,
    visualization_path: Path | str | None = None,
) -> dict[str, Any]:
    """
    Full toy pipeline: topology, task, environment trace, validation, toy executor.

    ``visualization_path``: if set, writes a topology PNG via :func:`plot_topology`.
    """
    from icg_restore_artifact.visualization.plot_topology import plot_topology

    topo = build_topology("EC-S", seed=seed)
    validate_document("topology.schema.json", topo)
    intent = generate_task(REGIONAL_ACCESS_COVERAGE_RECOVERY, "EC-S", seed=seed + 11)
    validate_document("task_intent.schema.json", intent)
    primitives = _primitives_for_physical_edge(topo)
    package = build_task_package(
        package_id=f"pkg-demo-{seed}",
        scenario_id=intent["scenario_id"],
        graph_id=topo["graph_id"],
        task_type=intent["task_type"],
        primitives=primitives,
        metadata={"demo": True},
    )
    validate_document("task_package.schema.json", package)
    cross_errs = validate_package_against_intent(intent, package)
    catalog_errs = validate_primitive_catalog(package)
    trace = generate_environment_trace(
        length=5,
        seed=seed,
        trace_id=f"trace-demo-{seed}",
        topology=topo,
        graph_id=topo["graph_id"],
    )
    validate_document("environment_trace.schema.json", trace)

    env_state_after_one = simulate_env_step(
        build_initial_simulation_state(topo, seed),
        STABLE_RECOVERY,
        step_idx=0,
        seed=seed,
    )

    validator_report = run_validator_suite(topology=topo, intent=intent, package=package, trace=trace)
    final_state, toy_report, steps = run_toy_executor(topo, package)
    metrics = summarize_run(final_state=final_state, steps=steps, intent=intent)

    viz_path: str | None = None
    if visualization_path is not None:
        viz_path = str(plot_topology(topo, visualization_path, layout_seed=seed))

    return {
        "topology": topo,
        "intent": intent,
        "package": package,
        "validation_cross": cross_errs,
        "validation_catalog": catalog_errs,
        "environment_trace": trace,
        "environment_state_after_mode_step": env_state_after_one,
        "validator_suite": validator_report,
        "metrics": metrics,
        "toy_indicators": toy_report.model_dump(mode="json"),
        "visualization_path": viz_path,
        "seed": seed,
    }
