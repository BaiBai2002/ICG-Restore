"""Synthetic environment mode labels (public artifact vocabulary)."""

from __future__ import annotations

from typing import Final

STABLE_RECOVERY: Final[str] = "Stable Recovery"
SECONDARY_FAILURE: Final[str] = "Secondary Failure"
CONGESTION_ESCALATION: Final[str] = "Congestion Escalation"
DELAYED_OBSERVATION: Final[str] = "Delayed Observation"
REGIONAL_ISOLATION_DRIFT: Final[str] = "Regional Isolation Drift"

ALL_MODES: Final[tuple[str, ...]] = (
    STABLE_RECOVERY,
    SECONDARY_FAILURE,
    CONGESTION_ESCALATION,
    DELAYED_OBSERVATION,
    REGIONAL_ISOLATION_DRIFT,
)


def list_environment_modes() -> tuple[str, ...]:
    return ALL_MODES
