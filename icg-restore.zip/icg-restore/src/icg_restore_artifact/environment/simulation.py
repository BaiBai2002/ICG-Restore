"""Reproducible synthetic environment simulation and traces."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from icg_restore_artifact.config import DEFAULT_SCHEMA_VERSION
from icg_restore_artifact.environment import modes as em
from icg_restore_artifact.utils.io_utils import write_json
from icg_restore_artifact.utils.random_utils import new_rng
from icg_restore_artifact.utils.schema_utils import validate_document


def build_initial_simulation_state(topology: dict[str, Any], seed: int) -> dict[str, Any]:
    """Derive initial health, congestion, and isolation baselines from a topology."""
    rng = new_rng(seed)
    node_health = {
        n["id"]: round(rng.uniform(0.35, 0.92), 3) for n in topology.get("nodes", [])
    }
    edge_congestion = {
        e["id"]: round(rng.uniform(0.05, 0.65), 3) for e in topology.get("edges", [])
    }
    regional_isolation: dict[str, float] = {}
    for n in topology.get("nodes", []):
        reg = (n.get("attributes") or {}).get("region")
        if isinstance(reg, str):
            regional_isolation[reg] = regional_isolation.get(reg, 0.0) + 0.04
    regional_isolation = {k: round(min(1.0, v), 3) for k, v in regional_isolation.items()}
    return {
        "step_clock": 0,
        "node_health": node_health,
        "edge_congestion": edge_congestion,
        "observation_lag": round(rng.uniform(0.0, 0.2), 3),
        "regional_isolation": regional_isolation,
    }


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def simulate_env_step(
    state: dict[str, Any],
    mode: str,
    step_idx: int,
    seed: int = 0,
) -> dict[str, Any]:
    """Return an updated simulation state (non-mutating) for one discrete step."""
    if mode not in em.ALL_MODES:
        raise ValueError(f"unknown environment mode {mode!r}")
    rng = new_rng(seed + step_idx * 1_000_003)
    next_state = copy.deepcopy(state)
    next_state["step_clock"] = int(step_idx)

    node_health: dict[str, float] = dict(next_state.get("node_health") or {})
    edge_congestion: dict[str, float] = dict(next_state.get("edge_congestion") or {})
    obs_lag = float(next_state.get("observation_lag") or 0.0)
    regional_iso: dict[str, float] = dict(next_state.get("regional_isolation") or {})

    if mode == em.STABLE_RECOVERY:
        for nid in list(node_health.keys()):
            node_health[nid] = _clamp01(node_health[nid] + rng.uniform(0.01, 0.06))
        for eid in list(edge_congestion.keys()):
            edge_congestion[eid] = _clamp01(edge_congestion[eid] - rng.uniform(0.01, 0.04))
        obs_lag = _clamp01(obs_lag - 0.02)
    elif mode == em.SECONDARY_FAILURE:
        if node_health:
            victim = rng.choice(list(node_health.keys()))
            node_health[victim] = _clamp01(node_health[victim] - rng.uniform(0.15, 0.35))
    elif mode == em.CONGESTION_ESCALATION:
        for eid in list(edge_congestion.keys()):
            if rng.random() < 0.55:
                edge_congestion[eid] = _clamp01(edge_congestion[eid] + rng.uniform(0.03, 0.12))
    elif mode == em.DELAYED_OBSERVATION:
        obs_lag = _clamp01(obs_lag + rng.uniform(0.02, 0.08))
    elif mode == em.REGIONAL_ISOLATION_DRIFT:
        for reg in list(regional_iso.keys()):
            regional_iso[reg] = _clamp01(regional_iso[reg] + rng.uniform(0.01, 0.05))

    next_state["node_health"] = node_health
    next_state["edge_congestion"] = edge_congestion
    next_state["observation_lag"] = round(obs_lag, 3)
    next_state["regional_isolation"] = {k: round(v, 3) for k, v in regional_iso.items()}
    return next_state


def _single_event(
    *,
    step_idx: int,
    mode: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    doc = {
        "schema_version": DEFAULT_SCHEMA_VERSION,
        "event_id": f"ev-{step_idx:04d}",
        "mode": mode,
        "step_idx": step_idx,
        "payload": payload,
    }
    validate_document("environment_event.schema.json", doc)
    return doc


def generate_environment_trace(
    *,
    length: int,
    seed: int,
    trace_id: str,
    mode_schedule: list[str] | None = None,
    graph_id: str = "",
    initial_state: dict[str, Any] | None = None,
    topology: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Simulate ``length`` steps; modes cycle or follow ``mode_schedule``."""
    if length < 0:
        raise ValueError("length must be non-negative")
    schedule = mode_schedule or list(em.ALL_MODES)
    if not schedule:
        raise ValueError("mode_schedule must be non-empty when provided")
    state: dict[str, Any]
    if initial_state is not None:
        state = copy.deepcopy(initial_state)
    elif topology is not None:
        state = build_initial_simulation_state(topology, seed)
    else:
        state = {
            "step_clock": 0,
            "node_health": {"synthetic": 0.7},
            "edge_congestion": {"synthetic": 0.3},
            "observation_lag": 0.1,
            "regional_isolation": {"R1": 0.2},
        }

    steps_out: list[dict[str, Any]] = []
    for i in range(length):
        mode = schedule[i % len(schedule)]
        state = simulate_env_step(state, mode, step_idx=i, seed=seed)
        payload = {
            "summary": f"Applied mode {mode} at step {i}.",
            "mode_index": i % len(schedule),
        }
        event = _single_event(step_idx=i, mode=mode, payload=payload)
        steps_out.append(
            {
                "step_idx": i,
                "mode": mode,
                "state_after": state,
                "event": event,
            }
        )

    trace = {
        "schema_version": DEFAULT_SCHEMA_VERSION,
        "trace_id": trace_id,
        "seed": seed,
        "graph_id": graph_id,
        "steps": steps_out,
        "metadata": {
            "synthetic": True,
            "generator": "icg_restore_artifact.environment.simulation",
            "length": length,
        },
    }
    validate_document("environment_trace.schema.json", trace)
    return trace


def export_environment_trace(trace: dict[str, Any], path: Path | str, *, indent: int = 2) -> Path:
    out = Path(path)
    write_json(out, trace, indent=indent)
    return out.resolve()
