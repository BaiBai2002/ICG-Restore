"""Synthetic heterogeneous scene graphs (EC-S / EC-M / EC-L)."""

from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.topology.topology_export import export_topology_json

__all__ = ["build_topology", "export_topology_json"]
