"""Public node-type vocabulary for synthetic heterogeneous scene graphs."""

from __future__ import annotations

from typing import Final

COORDINATION_CENTER: Final[str] = "Coordination Center"
BACKBONE_GATEWAY: Final[str] = "Backbone Gateway"
CORE_SERVICE_NODE: Final[str] = "Core Service Node"
RELAY_NODE: Final[str] = "Relay Node"
ACCESS_CLUSTER: Final[str] = "Access Cluster"
CHANNEL_RESOURCE: Final[str] = "Channel Resource"

ALL_NODE_TYPES: Final[tuple[str, ...]] = (
    COORDINATION_CENTER,
    BACKBONE_GATEWAY,
    CORE_SERVICE_NODE,
    RELAY_NODE,
    ACCESS_CLUSTER,
    CHANNEL_RESOURCE,
)
