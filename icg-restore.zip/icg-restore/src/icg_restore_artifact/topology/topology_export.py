"""Export topology documents to JSON."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from icg_restore_artifact.utils.io_utils import write_json


def export_topology_json(topology: dict[str, Any], path: Path | str, *, indent: int = 2) -> Path:
    """Write ``topology`` to ``path`` (UTF-8, sorted keys). Returns resolved path."""
    out = Path(path)
    write_json(out, topology, indent=indent)
    return out.resolve()
