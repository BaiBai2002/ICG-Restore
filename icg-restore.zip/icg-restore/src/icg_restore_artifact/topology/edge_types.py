"""Public edge-type vocabulary (logical + physical relations)."""

from __future__ import annotations

from typing import Final

PHYSICAL_CONNECTIVITY: Final[str] = "physical_connectivity"
LOGICAL_DEPENDENCY: Final[str] = "logical_dependency"
SERVICE_BEARING: Final[str] = "service_bearing"
CHANNEL_MAPPING: Final[str] = "channel_mapping"

ALL_EDGE_TYPES: Final[tuple[str, ...]] = (
    PHYSICAL_CONNECTIVITY,
    LOGICAL_DEPENDENCY,
    SERVICE_BEARING,
    CHANNEL_MAPPING,
)
