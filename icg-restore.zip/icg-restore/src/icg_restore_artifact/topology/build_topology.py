"""Deterministic synthetic heterogeneous scene graphs for EC-S / EC-M / EC-L."""

from __future__ import annotations

from random import Random
from typing import Any

from icg_restore_artifact.config import (
    DEFAULT_SCHEMA_VERSION,
    GENERATOR_DEFAULTS,
    SCALE_PROFILES,
    VALID_SCALES,
)
from icg_restore_artifact.topology import edge_types as et
from icg_restore_artifact.topology import node_types as nt
from icg_restore_artifact.utils.random_utils import new_rng
from icg_restore_artifact.utils.schema_utils import validate_document


def _regions(rng: Random) -> list[str]:
    return ["R1", "R2", "R3"]


def _node_attrs(rng: Random, role: str) -> dict[str, Any]:
    regions = _regions(rng)
    return {
        "region": rng.choice(regions),
        "operational_status": round(rng.uniform(0.35, 0.95), 3),
        "load_factor": round(rng.uniform(0.1, 0.9), 3),
        "role_tag": role,
    }


def _edge_attrs(rng: Random, *, degraded_bias: float = 0.15) -> dict[str, Any]:
    latency = rng.choice(["low", "medium", "high"])
    is_degraded = rng.random() < degraded_bias
    return {
        "latency_class": latency,
        "residual_capacity": round(rng.uniform(0.2, 1.0), 3),
        "is_degraded": is_degraded,
    }


def build_topology(scale: str, seed: int = 0) -> dict[str, Any]:
    """Construct a validated synthetic topology for the given paper-aligned scale."""
    if scale not in VALID_SCALES:
        raise ValueError(f"scale must be one of {VALID_SCALES}, got {scale!r}")
    profile = SCALE_PROFILES[scale]
    rng = new_rng(seed)
    B = profile.backbone_gateways
    C = profile.core_services
    R = profile.relay_nodes
    A = profile.access_clusters
    H = profile.channel_resources

    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    e_counter = 0

    def add_edge(
        src: str,
        tgt: str,
        etype: str,
        *,
        degraded_bias: float = 0.15,
    ) -> None:
        nonlocal e_counter
        eid = f"e-{e_counter}"
        e_counter += 1
        edges.append(
            {
                "id": eid,
                "source": src,
                "target": tgt,
                "type": etype,
                "attributes": _edge_attrs(rng, degraded_bias=degraded_bias),
            }
        )

    cc_id = "cc-0"
    nodes.append(
        {
            "id": cc_id,
            "type": nt.COORDINATION_CENTER,
            "label": "Coordination Center 0",
            "attributes": _node_attrs(rng, "coordination"),
        }
    )

    bg_ids = [f"bg-{i}" for i in range(B)]
    for i in range(B):
        nodes.append(
            {
                "id": bg_ids[i],
                "type": nt.BACKBONE_GATEWAY,
                "label": f"Backbone Gateway {i}",
                "attributes": _node_attrs(rng, "backbone"),
            }
        )
        add_edge(cc_id, bg_ids[i], et.PHYSICAL_CONNECTIVITY, degraded_bias=0.1)

    cs_ids = [f"cs-{i}" for i in range(C)]
    for j in range(C):
        nodes.append(
            {
                "id": cs_ids[j],
                "type": nt.CORE_SERVICE_NODE,
                "label": f"Core Service {j}",
                "attributes": _node_attrs(rng, "core"),
            }
        )
        add_edge(bg_ids[j % B], cs_ids[j], et.PHYSICAL_CONNECTIVITY, degraded_bias=0.12)

    rn_ids = [f"rn-{k}" for k in range(R)]
    for k in range(R):
        nodes.append(
            {
                "id": rn_ids[k],
                "type": nt.RELAY_NODE,
                "label": f"Relay {k}",
                "attributes": _node_attrs(rng, "relay"),
            }
        )
        add_edge(bg_ids[k % B], rn_ids[k], et.PHYSICAL_CONNECTIVITY, degraded_bias=0.18)

    ac_ids = [f"ac-{a}" for a in range(A)]
    for a in range(A):
        nodes.append(
            {
                "id": ac_ids[a],
                "type": nt.ACCESS_CLUSTER,
                "label": f"Access Cluster {a}",
                "attributes": _node_attrs(rng, "access"),
            }
        )
        add_edge(rn_ids[a % R], ac_ids[a], et.PHYSICAL_CONNECTIVITY, degraded_bias=0.2)

    cr_ids = [f"cr-{h}" for h in range(H)]
    for h in range(H):
        nodes.append(
            {
                "id": cr_ids[h],
                "type": nt.CHANNEL_RESOURCE,
                "label": f"Channel Resource {h}",
                "attributes": _node_attrs(rng, "channel"),
            }
        )
        add_edge(cr_ids[h], bg_ids[h % B], et.CHANNEL_MAPPING, degraded_bias=0.08)

    for j in range(max(0, C - 1)):
        add_edge(cs_ids[j], cs_ids[j + 1], et.LOGICAL_DEPENDENCY, degraded_bias=0.05)

    for a in range(A):
        cs_target = cs_ids[a % C]
        add_edge(cs_target, ac_ids[a], et.SERVICE_BEARING, degraded_bias=0.14)

    add_edge(cc_id, cs_ids[0], et.LOGICAL_DEPENDENCY, degraded_bias=0.05)

    graph_id = f"{GENERATOR_DEFAULTS.topology_prefix}-{scale}-{seed}"
    doc: dict[str, Any] = {
        "schema_version": DEFAULT_SCHEMA_VERSION,
        "graph_id": graph_id,
        "scale": scale,
        "notes": (
            "Synthetic heterogeneous scene graph for public artifact demonstration; "
            "not a confidential benchmark instance."
        ),
        "nodes": nodes,
        "edges": edges,
        "metadata": {
            "synthetic": True,
            "generator": "icg_restore_artifact.topology.build_topology",
            "seed": seed,
            "scale": scale,
            "node_count": len(nodes),
            "edge_count": len(edges),
        },
    }
    validate_document("topology.schema.json", doc)
    return doc
