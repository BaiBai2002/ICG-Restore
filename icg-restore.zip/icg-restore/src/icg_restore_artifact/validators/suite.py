"""Batch runner for public validators."""

from __future__ import annotations

from typing import Any

from icg_restore_artifact.validators.budget_feasibility import validate_budget_feasibility
from icg_restore_artifact.validators.causal_consistency import validate_causal_consistency
from icg_restore_artifact.validators.rule_consistency import validate_rule_consistency
from icg_restore_artifact.validators.schema_completeness import validate_schema_completeness
from icg_restore_artifact.validators.window_feasibility import validate_window_feasibility


def run_validator_suite(
    *,
    topology: dict[str, Any] | None = None,
    intent: dict[str, Any] | None = None,
    package: dict[str, Any] | None = None,
    trace: dict[str, Any] | None = None,
) -> dict[str, list[str]]:
    """
    Run all applicable checks. Keys are omitted when both inputs are absent.

    This layer is non-exhaustive and does not encode confidential repair policies.
    """
    out: dict[str, list[str]] = {}
    sc = validate_schema_completeness(
        topology=topology, intent=intent, package=package, trace=trace
    )
    if sc:
        out["schema_completeness"] = sc

    if intent is not None:
        rc = validate_rule_consistency(intent, package=package)
        if rc:
            out["rule_consistency"] = rc

    if intent is not None and package is not None:
        bf = validate_budget_feasibility(intent, package)
        if bf:
            out["budget_feasibility"] = bf
        wf = validate_window_feasibility(intent, package)
        if wf:
            out["window_feasibility"] = wf

    if topology is not None and package is not None:
        cc = validate_causal_consistency(package, topology)
        if cc:
            out["causal_consistency"] = cc

    return out
