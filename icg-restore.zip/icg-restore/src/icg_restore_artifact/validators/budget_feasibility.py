"""Toy energy accounting: uniform per-step cost (public spec only)."""

from __future__ import annotations

from typing import Any


def validate_budget_feasibility(
    intent: dict[str, Any],
    package: dict[str, Any],
    *,
    energy_per_step: int = 1,
) -> list[str]:
    """Ensure total implied energy use does not exceed ``intent.budget.energy_units``."""
    bud = intent.get("budget") or {}
    if not isinstance(bud, dict):
        return ["intent.budget must be an object"]
    cap = bud.get("energy_units")
    if not isinstance(cap, int):
        return ["intent.budget.energy_units must be an integer"]
    steps = package.get("primitives") or []
    need = len(steps) * energy_per_step
    if need > cap:
        return [
            f"package uses ~{need} energy units (assuming {energy_per_step} per step) "
            f"but budget allows {cap}"
        ]
    max_steps = bud.get("max_primitive_steps")
    if isinstance(max_steps, int) and len(steps) > max_steps:
        return [
            f"package has {len(steps)} primitives exceeding budget.max_primitive_steps {max_steps}"
        ]
    return []
