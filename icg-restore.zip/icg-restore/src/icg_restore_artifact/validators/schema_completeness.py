"""Required-field checks without replacing JSON Schema validation."""

from __future__ import annotations

from typing import Any

_TOPOLOGY_KEYS = frozenset({"schema_version", "graph_id", "scale", "nodes", "edges", "metadata"})
_INTENT_KEYS = frozenset(
    {
        "schema_version",
        "scenario_id",
        "task_type",
        "scale",
        "goal",
        "priority_objects",
        "budget",
        "time_window",
        "constraints",
        "completion_criteria",
    }
)
_PACKAGE_KEYS = frozenset({"schema_version", "package_id", "scenario_id", "graph_id", "primitives"})
_TRACE_KEYS = frozenset({"schema_version", "trace_id", "seed", "steps"})


def validate_schema_completeness(
    *,
    topology: dict[str, Any] | None = None,
    intent: dict[str, Any] | None = None,
    package: dict[str, Any] | None = None,
    trace: dict[str, Any] | None = None,
) -> list[str]:
    """Return messages for missing top-level keys expected by the public artifact."""
    errors: list[str] = []
    if topology is not None:
        missing = sorted(_TOPOLOGY_KEYS - topology.keys())
        if missing:
            errors.append(f"topology missing keys: {', '.join(missing)}")
    if intent is not None:
        missing = sorted(_INTENT_KEYS - intent.keys())
        if missing:
            errors.append(f"task intent missing keys: {', '.join(missing)}")
    if package is not None:
        missing = sorted(_PACKAGE_KEYS - package.keys())
        if missing:
            errors.append(f"task package missing keys: {', '.join(missing)}")
    if trace is not None:
        missing = sorted(_TRACE_KEYS - trace.keys())
        if missing:
            errors.append(f"environment trace missing keys: {', '.join(missing)}")
    return errors
