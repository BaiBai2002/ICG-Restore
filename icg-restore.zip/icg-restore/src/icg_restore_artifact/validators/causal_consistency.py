"""Lightweight causal checks on primitive order versus topology (toy semantics)."""

from __future__ import annotations

from typing import Any


def validate_causal_consistency(package: dict[str, Any], topology: dict[str, Any]) -> list[str]:
    """
    Enforce a small public rule: ``restore_link`` on an edge requires both endpoints
    to have been targeted by ``activate_node`` earlier in the plan.
    """
    errors: list[str] = []
    node_ids = {str(n.get("id")) for n in topology.get("nodes", []) if n.get("id")}
    edge_by_id: dict[str, dict[str, Any]] = {
        str(e["id"]): e for e in topology.get("edges", []) if e.get("id")
    }
    activated: set[str] = set()
    for i, step in enumerate(package.get("primitives") or []):
        name = step.get("name")
        args = step.get("args") or {}
        if name == "activate_node":
            nid = str(args.get("node_id", ""))
            if nid and nid not in node_ids:
                errors.append(f"step {i}: activate_node references unknown node {nid!r}")
            if nid:
                activated.add(nid)
        elif name == "restore_link":
            eid = str(args.get("edge_id", ""))
            edge = edge_by_id.get(eid)
            if not edge:
                errors.append(f"step {i}: restore_link references unknown edge {eid!r}")
                continue
            for endpoint in (str(edge.get("source", "")), str(edge.get("target", ""))):
                if endpoint and endpoint not in activated:
                    errors.append(
                        f"step {i}: restore_link on {eid} expected prior activate_node for {endpoint}"
                    )
        elif name == "reroute_flow":
            eid = str(args.get("edge_id", ""))
            if eid and eid not in edge_by_id:
                errors.append(f"step {i}: reroute_flow references unknown edge {eid!r}")
        elif name == "clear_fault_flag":
            nid = str(args.get("node_id", ""))
            if nid and nid not in node_ids:
                errors.append(f"step {i}: clear_fault_flag references unknown node {nid!r}")
    return errors
