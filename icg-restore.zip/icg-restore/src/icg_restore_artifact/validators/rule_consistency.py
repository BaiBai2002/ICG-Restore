"""Cross-field consistency within intents and supporting documents (toy rules)."""

from __future__ import annotations

from typing import Any


def validate_rule_consistency(
    intent: dict[str, Any],
    *,
    package: dict[str, Any] | None = None,
) -> list[str]:
    """Check non-proprietary alignment between budget, windows, and optional rule_bounds."""
    errors: list[str] = []
    tw = intent.get("time_window") or {}
    if isinstance(tw, dict):
        start, end = tw.get("start_unit"), tw.get("end_unit")
        if isinstance(start, int) and isinstance(end, int) and end <= start:
            errors.append("time_window end_unit must be greater than start_unit")

    bud = intent.get("budget") or {}
    if isinstance(bud, dict):
        for k in ("energy_units", "max_primitive_steps"):
            v = bud.get(k)
            if isinstance(v, int) and v < 0:
                errors.append(f"budget.{k} must be non-negative")

    rb = intent.get("rule_bounds") or {}
    if isinstance(rb, dict) and isinstance(bud, dict):
        ms_intent = bud.get("max_primitive_steps")
        ms_rb = rb.get("max_primitive_steps")
        if isinstance(ms_intent, int) and isinstance(ms_rb, int) and ms_intent != ms_rb:
            errors.append("budget.max_primitive_steps and rule_bounds.max_primitive_steps disagree")
        eu_i = bud.get("energy_units")
        eu_r = rb.get("energy_units")
        if isinstance(eu_i, int) and isinstance(eu_r, int) and eu_i != eu_r:
            errors.append("budget.energy_units and rule_bounds.energy_units disagree")

    if package is not None:
        if package.get("scenario_id") != intent.get("scenario_id"):
            errors.append("package scenario_id does not match intent scenario_id")

    return errors
