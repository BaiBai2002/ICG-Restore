"""Toy schedule feasibility against the declared planning window."""

from __future__ import annotations

from typing import Any


def validate_window_feasibility(
    intent: dict[str, Any],
    package: dict[str, Any],
    *,
    time_units_per_primitive: int = 2,
) -> list[str]:
    """
    Assume each primitive consumes a fixed number of abstract time units.
    Sum must fit inside ``time_window`` span (inclusive interpretation of endpoints).
    """
    tw = intent.get("time_window") or {}
    if not isinstance(tw, dict):
        return ["intent.time_window must be an object"]
    start, end = tw.get("start_unit"), tw.get("end_unit")
    if not isinstance(start, int) or not isinstance(end, int):
        return ["intent.time_window start_unit and end_unit must be integers"]
    span = end - start
    if span <= 0:
        return ["intent time window span is non-positive"]
    steps = len(package.get("primitives") or [])
    need = steps * time_units_per_primitive
    if need > span:
        return [
            f"schedule needs ~{need} time units (assuming {time_units_per_primitive} per primitive) "
            f"but window span is {span}"
        ]
    return []
