"""ICG-Restore public research artifact — toy generators, schemas, and demos."""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = ["__version__"]
