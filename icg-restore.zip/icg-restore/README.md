# ICG-Restore — Public Supplementary Software Artifact

This repository is a **peer-reviewed–style supplementary software artifact** for *ICG-Restore*: a task–intent–constrained, graph-augmented framework for **high-level restoration planning** after disasters, in the setting of **emergency communication service recovery**. The code and data here instantiate a **deliberately reduced public slice** of the ideas in the manuscript. It supports **intent-level documentation**, **schema-level interoperability**, and **pedagogical reproduction** of small synthetic pipelines.

## Distinction from the full internal pipeline

The paper describes an integrated system: **task intent compilation**; construction of a **heterogeneous scene graph** and a **recovery knowledge graph (RKG)**; **graph-aware retrieval**; **staged planning** (stage-wise candidate generation); **rule-consistent minimal-edit repair**; value screening; **proxy (safe) execution** with an **abstract evaluator**; and final ranking.

**This public artifact does not ship that full pipeline.** It provides:

- **Synthetic heterogeneous scene graphs** (JSON “topology” documents) at **EC-S / EC-M / EC-L–labeled scales** with **deterministic generation** in code, plus **small frozen examples** in `data/topo_examples/` (where noted, some JSON examples use a compact motif and explicitly state when they are not full paper-scale graphs).
- **Structured task intents and task packages** that abstract the output of **intent compilation** and **staged planning**, without releasing confidential prompt text or model weights.
- A **descriptive layer** for **rule-consistent minimal-edit repair** (repair *categories* and validation helpers), **not** the complete proprietary repair policy used internally.
- A **toy abstract executor** and **toy indicators** that illustrate state updates only; they are **not** the paper’s evaluation engine and **not** a claim of operational fidelity.

Researchers seeking **quantitative agreement** with the article’s tables must use the **manuscript, its registered evaluation protocol, and any publisher- or author-hosted materials explicitly tied to that protocol**—not inference from this repository alone.

## Explicit scope boundaries

| In scope (public artifact) | Out of scope (not in this repository) |
|----------------------------|----------------------------------------|
| JSON Schemas under `schemas/` | Full experimental **result tables**, wide **CSV/TeX** aggregates, or significance machinery from internal runs |
| Deterministic **synthetic** generators in `src/icg_restore_artifact/` | **Confidential prompts**, verbatim production LLM templates, or model **weights** |
| Small **example JSON** and optional figures under `data/` | **Hidden benchmark instances**, proprietary **traces**, or full **run logs** |
| **Lightweight validators** and **toy** simulation / execution | **Canonical** paper evaluation drivers, ablations, or **internal-only** aggregation code |
| Runnable **`examples/`** and **`pytest`** without API keys | Live cloud inference, paid keys, or non-reproducible external dependencies |

All restoration actions are **abstract primitives**. Nothing in this repository **executes** real network operations.

## Explicit limitations

1. **Toy executor and metrics** are **illustrative**; they do **not** reproduce proxy metrics, CSR, or efficiency statistics from the paper.
2. **Environment modes** are **simplified discrete updates**; they do **not** calibrate to field telemetry or operator consoles.
3. **`data/topo_examples/`** files labeled as **lightweight illustrative slices** are **not** bitwise-identical to the largest graphs produced by `build_topology("EC-M")` / `build_topology("EC-L")`; the **code generator** is authoritative for full synthetic counts.
4. **Reproducibility** is asserted for **this package’s** scripts, seeds, and schemas—**not** for unpublished LLM calls or unreleased corpora.

## Repository layout

| Path | Role |
|------|------|
| `schemas/` | JSON Schema definitions (topology, task intent, task package, environment event, environment trace). |
| `docs/` | Scope, terminology, reproducibility, visualization. |
| `data/*_examples/` | Small validated JSON fixtures; one **invalid** package for negative testing. |
| `data/visualization/` | **Regenerate** publication PNGs via `examples/demo_visualize_topology.py` (raster files may be absent until you run scripts). |
| `src/icg_restore_artifact/` | Installable Python package. |
| `examples/` | End-to-end and partial demos (no secrets). |
| `tests/` | `pytest` suite (headless Matplotlib). |

## Installation

```bash
cd icg-restore-artifact
python -m venv .venv
# Windows: .venv\Scripts\activate
# Unix:    source .venv/bin/activate
pip install -e ".[dev]"
```

The package root for schemas and `data/` is resolved from **`icg_restore_artifact.config.artifact_root()`** (repository root when installed editable from a git checkout).

## Quick start

```bash
export PYTHONPATH=src   # Unix; Windows: set PYTHONPATH=src
python examples/demo_validate_examples.py
python examples/demo_visualize_topology.py   # writes PNGs under data/visualization/
python examples/demo_end_to_end_artifact.py
python -m pytest
```

## Citation

1. **Software (this repository):** after you assign a public URL and, if applicable, a Zenodo DOI, record them in your reference manager. The `CITATION.cff` file provides a **Citation File Format** entry; expand **`preferred-citation`** with the **final author list, venue, volume, and DOI** from the camera-ready paper when available.
2. **Article:** cite the peer-reviewed ICG-Restore publication per your venue’s style once it appears (title and year are seeded in `CITATION.cff`).

Do not treat this `README` or the toy metrics as sources of **numerical results** reported in the paper.

## License

MIT — see `LICENSE`.

## Further reading

- `docs/overview.md` — Relation to the manuscript and terminology map.  
- `docs/artifact_scope.md` — Included vs excluded materials.  
- `docs/schemas.md` — JSON Schema `$id` namespace convention.  
- `docs/reproducibility.md` — Seeds, environments, and honest reproducibility claims.  
- `RELEASE_CHECKLIST.md` — Pre-release audit.  
- `GITHUB_UPLOAD_GUIDE.md` — Publishing the repository safely.
