"""End-to-end public artifact demo: generate, validate, simulate, toy executor, figures, bundle."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import artifact_root, data_dir
from icg_restore_artifact.demo.demo_pipeline import run_toy_demo
from icg_restore_artifact.demo.export_demo_bundle import export_bundle
from icg_restore_artifact.visualization.export_static_figures import export_all_publication_figures
from icg_restore_artifact.visualization.plot_task_graph import plot_task_graph


def main() -> None:
    seed = 42
    viz_dir = data_dir() / "visualization"
    export_all_publication_figures(base_dir=viz_dir)

    demo_png = viz_dir / "demo_end_to_end_topology.png"
    summary = run_toy_demo(seed=seed, visualization_path=demo_png)
    plot_task_graph(summary["package"], viz_dir / "demo_end_to_end_task_graph.png")

    out_dir = artifact_root() / "outputs" / "examples"
    bundle = export_bundle(out_dir, seed=seed, visualization_path=demo_png)

    print(json.dumps(summary["toy_indicators"], indent=2, sort_keys=True))
    print(f"Bundle: {bundle}")
    print(f"Demo topology figure: {demo_png}")
    print("Publication figures (EC-S/M/L + pipeline):", viz_dir)


if __name__ == "__main__":
    main()
