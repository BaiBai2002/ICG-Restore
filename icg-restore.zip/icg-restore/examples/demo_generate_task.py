"""Generate validated task intents for every public task type."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import artifact_root
from icg_restore_artifact.task.generation import export_task_json, generate_task, validate_task_intent
from icg_restore_artifact.task.task_templates import ALL_TASK_TYPES
from icg_restore_artifact.utils.schema_utils import validate_document


def main() -> None:
    out_dir = artifact_root() / "outputs" / "examples"
    for tt in ALL_TASK_TYPES:
        intent = generate_task(tt, "EC-S", seed=0)
        validate_document("task_intent.schema.json", intent)
        assert not validate_task_intent(intent)
        export_task_json(intent, out_dir / f"intent_{tt}.json")
        print(f"OK intent_{tt}.json")
    print(f"Wrote task intents under {out_dir}")


if __name__ == "__main__":
    main()
