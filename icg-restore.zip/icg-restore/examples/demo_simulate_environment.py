"""Simulate a short environment trace and write JSON to ``outputs/examples``."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import artifact_root
from icg_restore_artifact.environment.simulation import export_environment_trace, generate_environment_trace
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.utils.schema_utils import validate_document


def main() -> None:
    topo = build_topology("EC-S", seed=2)
    trace = generate_environment_trace(
        length=6,
        seed=99,
        trace_id="examples-trace-99",
        topology=topo,
        graph_id=topo["graph_id"],
    )
    validate_document("environment_trace.schema.json", trace)
    out = artifact_root() / "outputs" / "examples" / "environment_trace.json"
    export_environment_trace(trace, out)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
