"""Render publication-quality topology PNGs (EC-S/M/L) and pipeline overview into ``data/visualization/``."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import data_dir
from icg_restore_artifact.visualization.export_static_figures import export_all_publication_figures


def main() -> None:
    base = data_dir() / "visualization"
    paths = export_all_publication_figures(base_dir=base)
    for name, p in sorted(paths.items()):
        print(f"Wrote {p}")
    print(f"Figures directory: {base}")


if __name__ == "__main__":
    main()
