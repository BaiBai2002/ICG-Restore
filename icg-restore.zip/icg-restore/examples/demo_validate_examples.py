"""Validate example JSON under ``data/*_examples/``; flag known invalid fixtures."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import data_dir
from icg_restore_artifact.repair.validation_rules import validate_primitive_catalog
from icg_restore_artifact.utils.io_utils import read_json
from icg_restore_artifact.utils.schema_utils import validate_document


def _schema_for(path: Path) -> str:
    name = path.name.lower()
    parent = path.parent.name.lower()
    if parent == "topo_examples":
        return "topology.schema.json"
    if parent == "task_examples" and name.startswith("intent_"):
        return "task_intent.schema.json"
    if parent == "task_examples" and name.startswith("package_"):
        return "task_package.schema.json"
    if parent == "env_examples":
        if "trace" in name:
            return "environment_trace.schema.json"
        return "environment_event.schema.json"
    raise ValueError(f"No schema mapping for {path}")


def main() -> None:
    base = data_dir()
    for sub in ("topo_examples", "task_examples", "env_examples"):
        folder = base / sub
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob("*.json")):
            schema = _schema_for(path)
            data = read_json(path)
            validate_document(schema, data)
            print(f"OK  schema {path.relative_to(base)} -> {schema}")
            if path.name == "package_invalid_unknown_primitive.json":
                errs = validate_primitive_catalog(data)
                assert errs, "expected catalog validation failure"
                print(f"    (expected) primitive catalog violations: {errs}")
    print("All discovered example JSON files validate against JSON Schema.")
    print("Invalid package example failed toy catalog check as intended.")


if __name__ == "__main__":
    main()
