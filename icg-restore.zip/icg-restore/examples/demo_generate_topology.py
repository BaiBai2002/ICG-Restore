"""Generate synthetic topologies for EC-S / EC-M / EC-L and save JSON under ``outputs/examples``."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from icg_restore_artifact.config import artifact_root
from icg_restore_artifact.topology.build_topology import build_topology
from icg_restore_artifact.topology.topology_export import export_topology_json
from icg_restore_artifact.utils.schema_utils import validate_document


def main() -> None:
    out_dir = artifact_root() / "outputs" / "examples"
    for scale in ("EC-S", "EC-M", "EC-L"):
        topo = build_topology(scale, seed=0)
        validate_document("topology.schema.json", topo)
        name = f"topology_{scale.lower().replace('-', '')}_seed0.json"
        export_topology_json(topo, out_dir / name)
        print(f"OK {name} nodes={len(topo['nodes'])} edges={len(topo['edges'])}")
    print(f"Wrote topologies under {out_dir}")


if __name__ == "__main__":
    main()
